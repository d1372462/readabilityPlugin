
import com.github.javaparser.ast.Node;
import extractors.ASTExtractor;
import models.Identifier;
import org.junit.jupiter.api.Test;
import parsing.ASTBuilder;

import java.util.*;

import static junit.framework.TestCase.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class AstExtractorTest {
    private final ASTExtractor astExtractor = new ASTExtractor();

    @Test
    public void extractIdentifiers_test()
    {
        String sourceCode = "class TestClass {int x; int y; int zz(int a){return a;} }";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        List<Identifier> identifiers =  astExtractor.extractIdentifiers(astNode);
        System.out.println(identifiers);
        List<String> expectedIdentifiers = new LinkedList<>(Arrays.asList(
                "TestClass",
                "x",
                "y",
                "zz",
                "a",
                "a")); // expected values
        // check size:
        assertEquals(expectedIdentifiers.size(), identifiers.size()); // (prevents case with more elements than expected)
        // check correct items:
        identifiers.stream()
                .forEach(identifier -> assertTrue(expectedIdentifiers.contains(identifier.getName())));
    }

}
