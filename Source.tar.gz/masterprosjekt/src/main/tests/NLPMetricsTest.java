
import com.github.javaparser.ast.Node;
import extractors.ASTExtractor;
import helperUtils.ASTUtils;
import metricsComputers.NLPMetrics;
import metricsComputers.StructuralMetrics;
import org.junit.jupiter.api.Test;
import parsing.ASTBuilder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit-tests for structural metrics.
 */
public class NLPMetricsTest {
    private NLPMetrics nlpMetrics = new NLPMetrics();
    private final ASTUtils astUtils = new ASTUtils();
    private final ASTExtractor astExtractor = new ASTExtractor();

    /**
     * Tests the avg comment-identifier-consistency between comments and identifiers
     */
    @Test
    public void MAX_CIC_POSITIVE()
    {
        String sourceCode =
                        "class Q {int dog; int y;    /** dog food */     int dog(int dog, int y){ int food; int u; return 0-1; } "
                        + System.lineSeparator()+" int z(int a, int b){ return 0-1*4; }}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0.5 // identifiers in method is found in comment in 2 of 4 possible
                , nlpMetrics.MAX_CIC.apply(astNode,sourceCode).doubleValue());
         sourceCode =
                "class Q {int dog; int y;    /** dog food */     int dog(int dog, int food){ return 0-1; } "
                        + System.lineSeparator()+" int z(int a, int b){ return 0-1*4; }}";
         astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1 // all identifiers in method is also found in comment-terms
                , nlpMetrics.MAX_CIC.apply(astNode,sourceCode).doubleValue());
         // merge the two (to test max is slected):
        sourceCode =
                "class Q {int dog; int y;    /** dog food */     int dog(int dog, int food){ return 0-1; } "
                        + System.lineSeparator()+" int z(int a, int b){ return 0-1*4; }" +
                        " /** dog food */     int dogz(int dog, int y){ int food; int u; return 0-1; } "+
                         System.lineSeparator()+" int zz(int a, int b){ return 0-1*4; }}";
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1 // all identifiers in method is also found in comment-terms
                , nlpMetrics.MAX_CIC.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Negative test for TC MAX
     */
    @Test
    public void TC_MAX_NEGATIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int dog_duct=3;" +
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 0; // expecting no matches
        assertEquals(expected, nlpMetrics.TC_MAX.apply(astNode, sourceCode));
    }

    /**
     * Negative test for TC MAX
     */
    @Test
    public void TC_AVG_NEGATIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int dog_duct=3;" +
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 0; // expecting no matches
        assertEquals(expected, nlpMetrics.AVG_TC.apply(astNode, sourceCode));
    }

    /**
     * Negative test for TC MAX
     */
    @Test
    public void TC_MIN_NEGATIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int dog_duct=3;" +
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 0; // expecting no matches
        assertEquals(expected, nlpMetrics.TC_MIN.apply(astNode, sourceCode));
    }

    /**
     * Negative test for ITID MIN
     */
    @Test
    public void ITID_MIN_NEGATIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int ijfirj=0;" +
                "int wspeed=3;" +
                "}}" +
                "public void dog_frog(){" +
                "if(true){" +
                "int ufhfu=3;" +
                "int csc =3;"+
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 0; // expecting no matches
        assertEquals(expected, nlpMetrics.MIN_ITID.apply(astNode, sourceCode));
    }

    /**
     * Negative test for ITID AVG
     */
    @Test
    public void ITID_AVG_NEGATIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void fefef(){" +
                "if(true){" +
                "int frgreg=0;" +
                "int fewfwe=3;" +
                "}}" +
                "public void dwdfeef(){" +
                "if(true){" +
                "int ufhfu=3;" +
                "int csc =3;"+
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 0; // expecting no matches
        assertEquals(expected, nlpMetrics.AVG_ITID.apply(astNode, sourceCode));
    }

    /**
     * Positive test for ITID MIN
     */
    @Test
    public void ITID_AVG_POSITIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int dog_cat=0;" +
                "int speed=3;" +
                "}}" +
                "public void dog_frog(){" +
                "if(true){" +
                "int ufhfu=3;" +
                "int csc =3;"+
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = 0.5; // expecting no matches
        assertEquals(expected, nlpMetrics.AVG_ITID.apply(astNode, sourceCode));
    }

    /**
     * Positive test for TC MIN
     */
    @Test
    public void TC_MIN_POSITIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int air_duct=3;" +
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 1/3;  // expecting match on 1 of 3 possible terms (air from air, supply, duct)
        assertEquals(expected, nlpMetrics.TC_MIN.apply(astNode, sourceCode));

        sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" + // --> candidate expected here
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int air_duct=3;" + // ---> candidate expected here
                "}" +
                "if(false){" +
                "int air_duct=4;" + // --> expected ignored (due to min)
                "}" +
                "}" +
                "}";
        astNode = new ASTBuilder().buildAST(sourceCode);
        expected = (double) 1/3;  // expecting 1 of 3 matches (air from air,duct,supply)
        assertEquals(expected, nlpMetrics.TC_MIN.apply(astNode, sourceCode));
    }


    /**
     * Positive test for TC MIN
     */
    @Test
    public void TC_AVG_POSITIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int air_duct=3;" +
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 1/3;  // expecting match on 1 of 3 possible terms (air from air, supply, duct)
        assertEquals(expected, nlpMetrics.AVG_TC.apply(astNode, sourceCode));

        sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" + // --> candidate expected here
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int air_duct=3;" + // ---> candidate expected here
                "}" +
                "if(false){" +
                "int air_duct=4;" + // --> expected ignored (due to min)
                "}" +
                "}" +
                "}";
        astNode = new ASTBuilder().buildAST(sourceCode);
        expected =  ( ((double)1/3) + ((double)1/3) + 1) / 3;  // expecting 3 pairs with results: 1,2 --> 1/3, 1,3 --> 1/3, 2,3 --> 1 = 0.5555....
        assertEquals(expected, nlpMetrics.AVG_TC.apply(astNode, sourceCode));
    }


    /**
     * Tests avg number-of-meanings (of identifiers)
     */
    @Test
    public void TC_MAX_POSITIVE()
    {
        String sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int air_duct=3;" +
                "}}" +
                "}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        Double expected = (double) 1/3;  // expecting match on 1 of 3 possible terms (air from air, supply, duct)
        assertEquals(expected, nlpMetrics.TC_MAX.apply(astNode, sourceCode));

         sourceCode = "class QQQ {" +
                "public void test_air(){" +
                "if(true){" +
                "int air_supply=0;" +
                "}}" +
                "public void test_air_supply(){" +
                "if(true){" +
                "int air_duct=3;" +
                "}" +
                "if(false){" +
                "int air_duct=4;" +
                "}" +
                "}" +
                "}";
         astNode = new ASTBuilder().buildAST(sourceCode);
         expected = (double) 1;  // expecting full match on air and duct on second and third if statement
        assertEquals(expected, nlpMetrics.TC_MAX.apply(astNode, sourceCode));
    }

}
