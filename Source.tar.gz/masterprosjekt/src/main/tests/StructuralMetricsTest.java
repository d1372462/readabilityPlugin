
import com.github.javaparser.ast.Node;
import extractors.ASTExtractor;
import helperUtils.ASTUtils;
import metricsComputers.StructuralMetrics;
import org.junit.jupiter.api.Test;
import parsing.ASTBuilder;

import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Unit-tests for structural metrics.
 */
public class StructuralMetricsTest {
    private StructuralMetrics structuralMetrics = new StructuralMetrics();
    private final ASTUtils astUtils = new ASTUtils();
    private final ASTExtractor astExtractor = new ASTExtractor();

    /**
     * Tests avg-number of identifiers (avg number of identifiers per line)
     */
    @Test
    public void avgNumberOfIdentifiers()
    {
        // setup ast-node to test:
        String sourceCode = "class TestClass {int x; int y; int zz(int a){return a;} }";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(6 // 6 identifiers on single line gives 5/1 = 5
                , structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests max-number of identifiers (max number of identifiers for any line)
     */
    @Test
    public void maxNumberOfIdentifiers()
    {
        // setup ast-node to test:
        String sourceCode = "class TestClass {int x; int y; int zz(int a, int b){return a;} }"; // 6 identifiers expected
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(7 // expect all on single line
                , structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC.apply(astNode,sourceCode).intValue());
    }

    /**
     * Tests avg branching factor with branches (positive)
     */
    @Test
    public void avgNumberOfBranches_positive()
    {
        // setup ast-node to test:
        String sourceCode = "class TestClass {int x; int y; int zz(int a, int b){ if (a==1){switch(a){case 0: return a; case 1: return 1;}}else{return 0;} } }"; // 2 if branches, 2 switch branches... should equal 4 total
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals((double) 4  // 4 branches on single line expected
                , structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests avg branching-factor with no branches (negative)
     */
    @Test
    public void avgNumberOfBranches_negative()
    {
        // setup ast-node to test:
        String sourceCode = "class TestClass {int x; int y; int zz(int a, int b){ return a; } }"; // no branching expected
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0
                , structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests avg identifier-length
     */
    @Test
    public void avgIdentifierLength()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y; int z(int a, int b){ return a; } }";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1
                , structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC.apply(astNode,sourceCode).doubleValue());
        sourceCode = "class QQ {int xX; int yy; int z(int a, int b){ return 0; } }";
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1.5
                , structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests max identifier-length
     */
    @Test
    public void maxIdentifierLength()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y; int zzz(int a, int b){ return a; } }"; // zzz is the longest
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(3
                , structuralMetrics.MAX_IDENTIFIER_LENGTH.apply(astNode,sourceCode).doubleValue());
        sourceCode = "class QQ {int xX; int yy; int z(int a, int b){ return a; } }"; // multiple longest of length 2
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(2
                , structuralMetrics.MAX_IDENTIFIER_LENGTH.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests avg arithmatic operations
     */
    @Test
    public void avgArithmeticOperations_positive()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y; int z(int a, int b){ return (a/2) + 1; } }"; // 2 arithmetic operations
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(2 / (double)astUtils.ASTNodeLineCount(astNode)
                , structuralMetrics.AVG_NUMBER_OF_ARITHMATIC_OPERATIONS.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests avg arithmatic operations
     */
    @Test
    public void avgArithmeticOperations_negative()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y; int z(int a, int b){ return a; } }";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0
                , structuralMetrics.AVG_NUMBER_OF_ARITHMATIC_OPERATIONS.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests the max occurance of any given character measure
     */
    @Test
    public void maxInstancesOfChar()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y; int z(int a, int b){ return a; } }"; // highest number of same character is 6 (n & t repeated 6 times)
        assertEquals(6
                , structuralMetrics.MAX_INSTANCES_OF_CHARS.apply(null,sourceCode).doubleValue());
    }

    /**
     * Tests the max occurance of any given identifier measure
     */
    @Test
    public void maxOccurencesOfIdentifier()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y; int z(int a, int b){ return a; } }"; // highest number of same character is 6 (n & t repeated 6 times)
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1
                , structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER.apply(astNode,sourceCode).doubleValue());
    }


    /**
     * Tests the max indents of any line measure (negative)
     */
    @Test
    public void maxNumbeOfIndents_negative()
    {
        // setup ast-node to test:
        String sourceCode = "class Q {int x; int y;  int z(int a, int b){ return a; } }"; // highest number of same character is 6 (n & t repeated 6 times)
        assertEquals(0
                , structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC.apply(null,sourceCode).doubleValue());
    }

    /**
     * Tests the max indents of any line measure (positive)
     */
    @Test
    public void maxNumbeOfIndents_positive()
    {
        // check with two indents:
        String sourceCode = "class Q {int x; int y;         int z(int a, int b){ return a; } }"; // highest number of same character is 6 (n & t repeated 6 times)
        assertEquals(2
                , structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC.apply(null,sourceCode).doubleValue());
        // check with one indents:
        sourceCode = "class Q {int x; int y;    int z(int a, int b){ return a; } }"; // highest number of same character is 6 (n & t repeated 6 times)
        assertEquals(1
                , structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC.apply(null,sourceCode).doubleValue());
    }

    /**
     * Tests the max indents of any line measure (positive)
     */
    @Test
    public void maxNumberOfNumbers_negative()
    {
        // check with two indents:
        String sourceCode = "class Q {int x; int y;         int z(int a, int b){ return a; } }"; // highest number of same character is 6 (n & t repeated 6 times)
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0
                , structuralMetrics.MAX_NUMBER_OF_NUMBERS.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests the max number of numbers for any given line
     */
    @Test
    public void maxNumberOfNumbers_positive()
    {
        // check with 1 number:
        String sourceCode = "class Q {int x; int y;         int z(int a, int b){ return 0; } }";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1
                , structuralMetrics.MAX_NUMBER_OF_NUMBERS.apply(astNode,sourceCode).doubleValue());
        // check with 2 numbers:
        sourceCode = "class Q {int x; int y;         int z(int a, int b){ return 0-1; } }";
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(2
                , structuralMetrics.MAX_NUMBER_OF_NUMBERS.apply(astNode,sourceCode).doubleValue());
        // check with multiple lines:
        sourceCode = "class Q {int x; int y;         int z(int a, int b){ return 0-1; } " // 2 numbers on this line
                + System.lineSeparator()+" int z(int a, int b){ return 0-1*4; }}"; // 3 numbers on this line
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(3
                , structuralMetrics.MAX_NUMBER_OF_NUMBERS.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests the avg number of numbers for all lines
     */
    @Test
    public void avgNumberOfNumbers()
    {
        String sourceCode = "class Q {int x; int y;         int z(int a, int b){ return 0-1; } "
                + System.lineSeparator()+" int z(int a, int b){ return 0-1*4; }}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(5 / (double)astUtils.ASTNodeLineCount(astNode)
                , structuralMetrics.AVG_NUMBER_OF_NUMBERS.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests the avg number of comments for all lines
     */
    @Test
    public void avgNumberOfComments()
    {
        String sourceCode =
                "/**" + System.lineSeparator() +
                        "* this is a comment " + System.lineSeparator() +
                        "*/ " + System.lineSeparator() +
                        "class Q {int x; int y;         int z(int a, int b){ return 0-1; } "
                        + System.lineSeparator()+" int z(int a, int b){ return 0-1*4; }}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals((double)3 / 5 // comment constitutes 3 of 5 lines
                , structuralMetrics.AVG_NUMBER_OF_COMMENTS.apply(astNode,sourceCode).doubleValue());
    }

    /**
     * Tests the avg number of periods for all lines
     */
    @Test
    public void avgNumberOfPeriods()
    {
        String sourceCode = "class Q {int x; int y;         int z(int a, int b){ System.out.println(\"hello!\"); return 0-1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(2
                , structuralMetrics.AVG_NUMBER_OF_PERIODS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfCommas_negative()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b){ System.out.println(\"hello!\"); return 0-1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0
                , structuralMetrics.AVG_NUMBER_OF_COMMAS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfCommas_positive()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 0-1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(2 // two commas on single line gives 2 expected
                , structuralMetrics.AVG_NUMBER_OF_COMMAS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfSpaces()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 0-1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(25 // 25 spaces on single line gives 25 expected
                , structuralMetrics.AVG_NUMBER_OF_SPACES.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfParenthesis_negative()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 0-1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0 // 0 spaces on single line gives 0 expected
                , structuralMetrics.AVG_NUMBER_OF_PARENTHESIS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfParenthesis_positive()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1>0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1 // 1 spaces on single line gives 1 expected
                , structuralMetrics.AVG_NUMBER_OF_PARENTHESIS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfComparisons_negative()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0 // 0 comparisons on single line gives 0 expected
                , structuralMetrics.AVG_NUMBER_OF_COMPARISONS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfComparisons_positive()
    {
        String sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1>0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(1 // 1 comparisons on single line gives 1 expected
                , structuralMetrics.AVG_NUMBER_OF_COMPARISONS.apply(astNode,sourceCode).doubleValue());
        sourceCode = "class Q {int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1>0 || 2>3 ? 0 : 1; }} ";
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(2 // 2 comparisons on single line gives 2 expected
                , structuralMetrics.AVG_NUMBER_OF_COMPARISONS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfAssignments_negative()
    {
        String sourceCode = "class Q {private int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1>0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0
                , structuralMetrics.AVG_NUMBER_OF_ASSIGNMENTS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfAssignments_positive()
    {
        String sourceCode = "class Q {int x; int y=0; Object o = new Object();  int z(int b, int u, int k){ int k = 0; System.out.println(\"hello!\"); return 1>0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(3 // 3 assignments on single line gives 2 expected
                , structuralMetrics.AVG_NUMBER_OF_ASSIGNMENTS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfLoops_negative()
    {
        String sourceCode = "class Q {private int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1>0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0 // 1 comparisons on single line gives 1 expected
                , structuralMetrics.AVG_NUMBER_OF_LOOPS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfLoops_positive()
    {
        String sourceCode = "class Q {private int x; int y;     void z(int b, int u, int k){ while(true){ int i =0;} for(int i=0; i < 10; i++){int x=0;} List i = new LinkedList(); for(Object o : i){}}} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(3 // 1 while loop, 1 traditional for-loop, and one simplified for-loop over 1 line
                , structuralMetrics.AVG_NUMBER_OF_LOOPS.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfBlankLines_negative()
    {
        String sourceCode = "class Q {private int x; int y;         int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1>0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(0 // 1 comparisons on single line gives 1 expected
                , structuralMetrics.AVG_NUMBER_OF_BLANK_LINES.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgNumberOfBlankLines_positive()
    {
        String sourceCode = "class Q {private int x; int y;     " +
                System.lineSeparator() + System.lineSeparator()
                + "    int z(int b, int u, int k){ System.out.println(\"hello!\"); return 1 > 0 ? 0 : 1; }} ";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals((double)1/3 // 1 blank line, 3 lines total makes 1/3 avg
                , structuralMetrics.AVG_NUMBER_OF_BLANK_LINES.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void avgLineLength()
    {
        String sourceCode = "class qq{" +System.lineSeparator()+
                "int x=99;"+System.lineSeparator()
                +"int y=0;}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(9
                , structuralMetrics.AVG_LINE_LENGTH_FUNC.apply(astNode,sourceCode).doubleValue());
    }

    @Test
    public void maxLineLength()
    {
        String sourceCode = "class qq{" +System.lineSeparator()+
                "int x=99;"+System.lineSeparator()
                +"int y=0;}";
        Node astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(9
                , structuralMetrics.MAX_LINE_LENGTH_FUNC.apply(astNode,sourceCode).doubleValue());

        sourceCode = "class qqx{" +System.lineSeparator()+
                "int x=99;"+System.lineSeparator()
                +"int y=0;}";
        astNode = new ASTBuilder().buildAST(sourceCode);
        assertEquals(10
                , structuralMetrics.MAX_LINE_LENGTH_FUNC.apply(astNode,sourceCode).doubleValue());
    }


}