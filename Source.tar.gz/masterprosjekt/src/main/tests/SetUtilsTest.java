import helperUtils.SetUtils;
import models.setModels.Tuple;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class SetUtilsTest {

    private final SetUtils setUtils = new SetUtils();
    @Test
    public void allPairsTest()
    {
        Set<Integer> ints = new HashSet<>(Arrays.asList(1,2,3));

        Set<Tuple<Integer,Integer>> allPairs = setUtils.allPairs(ints);
        Set<Tuple<Integer,Integer>> expected = new HashSet<>(Arrays.asList(
                new Tuple<>(1, 2),
                new Tuple<>(1, 3),
                new Tuple<>(2, 3)
        ));

        // check size:
        assertEquals(expected.size(),allPairs.size());

        System.out.println(allPairs);
        // check content:
        expected.stream().forEach(
                tuple -> assertTrue(allPairs.contains(tuple) || allPairs.contains(tuple.reversed()),
                        "Does not contain: "+tuple)
        );
    }
}


/*

1,2
1,3
2,3

 */