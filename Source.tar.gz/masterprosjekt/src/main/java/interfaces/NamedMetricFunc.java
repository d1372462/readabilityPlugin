package interfaces;

import com.github.javaparser.ast.Node;
import org.jetbrains.annotations.NotNull;

import java.util.function.BiFunction;

/**
 * Interface ensures that given metrics function has a string key and name
 * (to be overrided by speicific metrics)
 */
public interface NamedMetricFunc extends Comparable<NamedMetricFunc>, BiFunction<Node,String,Double> {
    /**
     * Provides a default string-key for node input metric
     *  ... to be overrided by specific metric interface default
     * @return
     */
    default String stringKey()
    {
        return "METRIC_FUNC";
    }

    /**
     * Provides a default string-name for node input metric
     *  ... to be overrided by specific metric interface default
     * @return
     */
    default String stringName()
    {
        return "METRIC_FUNC";
    }

    @Override
    default int compareTo(@NotNull NamedMetricFunc namedMetricFunc) {
        return stringName().compareTo(namedMetricFunc.stringName());
    }
}
