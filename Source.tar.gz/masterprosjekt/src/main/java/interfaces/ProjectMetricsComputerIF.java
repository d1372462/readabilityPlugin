package interfaces;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import models.setModels.MetricsSnapshot;
import models.setModels.Tuple;

import java.util.List;
import java.util.Map;

public interface ProjectMetricsComputerIF {
    MetricsSnapshot fetchOrCompute(String qualifiedName, String sourceCode);

    MetricsSnapshot computeAllOnSource(String sourceCodeString);

    Map<PsiClass, MetricsSnapshotIF> computeAllOnProject(Project project);

    Map<PsiClass, MetricsSnapshotIF> computeAllOnClasses(List<Tuple<PsiClass, String>> classList);

    MetricsSnapshot avgAll(Map<PsiClass, MetricsSnapshotIF> snapshotMaps);
}
