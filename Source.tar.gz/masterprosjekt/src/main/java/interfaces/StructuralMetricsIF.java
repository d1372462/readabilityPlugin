package interfaces;

import com.github.javaparser.ast.Node;
import java.util.function.Function;

public interface StructuralMetricsIF {
    /**
     * Computes Cyclomatic Complexity for given parse node
     * (Number of conditional branches)
     * @param  Node from abstract syntax tree
     */
    @FunctionalInterface
    interface CyclomaticComplexityFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "CC";
        }
        @Override
        default String stringName()
        {
            return "Cyclomatic Complexity";
        }
    }

    /**
     * Computes the average branching factor
     * @param ASTNode
     * @return AVG branching
     */
    @FunctionalInterface
    interface AVGCyclomaticComplexityFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_CC";
        }
        @Override
        default String stringName()
        {
            return "Cyclomatic Complexity (Average)";
        }
    }

    /**
     * Computes the max number of identifiers per line
     * @param ASTNode
     * @return AVG branching
     */
    @FunctionalInterface
    interface MaxNumberOfIdentifiersFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "MAX_NUMBER_OF_IDENTIFIERS";
        }
        @Override
        default String stringName()
        {
            return "Numer of identifiers (Max)";
        }
    }

    /**
     * Computes the average identifier length of all identifiers from node (recurcive)
     * @param ASTNode
     * @return AVG Identifier length
     */
    @FunctionalInterface
    interface AVGIdentifierLengthFunc extends NamedMetricFunc {
        @Override
        Double apply( Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_IDENTIFIER_LENGTH";
        }
        @Override
        default String stringName()
        {
            return "Identifier Length (Average)";
        }
    }

    /**
     * Computes the max number of occurrences of any single identifier
     * @param ASTNode
     * @return AVG Identifier length
     */
    @FunctionalInterface
    interface MaxOccurrenceOfIdentifier extends NamedMetricFunc {
        @Override
        Double apply( Node node, String source);
        @Override
        default String stringKey()
        {
            return "MAX_OCCURRENCE_OF_IDENTIFIER";
        }
        @Override
        default String stringName()
        {
            return "Occurrence of single identifier (Max)";
        }
    }

    /**
     * Computes the max identifier length of any identifiers from node (recurcive)
     * @param ASTNode
     * @return AVG Identifier length
     */
    @FunctionalInterface
    interface MaxIdentifierLengthFunc extends NamedMetricFunc {
        @Override
        Double apply( Node node, String source);
        @Override
        default String stringKey()
        {
            return "MAX_IDENTIFIER_LENGTH";
        }
        @Override
        default String stringName()
        {
            return "Identifier Length (Max)";
        }
    }

    /**
     * Computes the average line-length of given ASTNode when converted to code
     * @param ASTNode
     * @return
     */
    @FunctionalInterface
    interface AVGLineLengthFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);;
        @Override
        default String stringKey()
        {
            return "AVG_LINE_LENGTH";
        }
        @Override
        default String stringName()
        {
            return "Line Length (Average)";
        }
    }

    /**
     * Counts number of lines
     * @param ASTNode
     * @return
     */
    @FunctionalInterface
    interface NumberOfLinesFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);;
        @Override
        default String stringKey()
        {
            return "NUMBER_OF_LINES";
        }
        @Override
        default String stringName()
        {
            return "Number Of Lines";
        }
    }

    /**
     * Finds the length of the longest line in the ASTNode when converted to code
     * @param ASTNode
     * @return
     */
    @FunctionalInterface
    interface MaxLineLengthFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);;
        @Override
        default String stringKey()
        {
            return "MAX_LINE_LENGTH";
        }
        @Override
        default String stringName()
        {
            return "Line Length (Max)";
        }
    }

    /**
     * Counts number of identifiers from given ASTNode
     * @param ASTNode
     * @return number of identifiers
     */
    @FunctionalInterface
    interface NumberOfIdentifiersFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "NUMBER_OF_IDENTIFIERS";
        }
        @Override
        default String stringName()
        {
            return "Number Of Identifiers";
        }
    }

    /**
     * Computes average number of identifiers from given ASTNode
     * @param ASTNode
     * @return avg number of identifiers
     */
    @FunctionalInterface
    interface AVGNumberOfIdentifiersFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_IDENTIFIERS";
        }
        @Override
        default String stringName()
        {
            return "Number Of Identifiers (Average)";
        }
    }

    /**
     * Counts the max number of indents in any given line from AST node
     * @param ASTNode
     * @return MAX number of indents
     */
    @FunctionalInterface
    interface MaxNumberOfIndentsFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);;
        @Override
        default String stringKey()
        {
            return "MAX_NUMBER_OF_IDENTIFIERS";
        }
        @Override
        default String stringName()
        {
            return "Number Of Indents (Max)";
        }
    }

    /**
     * Counts the max number of indents in any given line from AST node
     * @param ASTNode
     * @return MAX number of indents
     */
    @FunctionalInterface
    interface AVGNumberOfIndentsFunc extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);;
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_INDENTS";
        }
        @Override
        default String stringName()
        {
            return "Number Of Indents (Average)";
        }
    }

    /**
     * Counts the max occurance of any given character in the AST Node
     * @param ASTNode to measure
     * @return double avg instances of any single char in all lines of the given ast node
     */
    @FunctionalInterface
    interface MaxInstancesOfChars extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);;
        @Override
        default String stringKey()
        {
            return "MAX_INSTANCES_OF_CHARS";
        }
        @Override
        default String stringName()
        {
            return "Instances of single chars (Max)";
        }
    }

    /**
     * Counts the average occurance of any given character in the AST Node
     * @param ASTNode to measure
     * @return double avg instances of any single char in all lines of the given ast node
     */
    @FunctionalInterface
    interface AVGInstancesOfChars extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_INSTANCES_OF_CHARS";
        }
        @Override
        default String stringName()
        {
            return "Instances of single chars (Average)";
        }
    }

    /**
     * Counts the max number of instances of a number in any given line in the AST node
     * sub-tree
     * @param ASTNode to measure
     * @return integer max instances of any single char in all lines of the given ast node
     */
    @FunctionalInterface
    interface MaxNumberOfNumbers extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "MAX_NUMBER_OF_NUMBERS";
        }
        @Override
        default String stringName()
        {
            return "Number of numbers (Max)";
        }
    }

    /**
     * Counts the average number of instances of a number in any given line in the AST node
     * sub-tree
     * @param ASTNode to measure
     * @return double avg instances of any single char in all lines of the given ast node
     */
    @FunctionalInterface
    interface AVGNumberOfNumbers extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_NUMBERS";
        }
        @Override
        default String stringName()
        {
            return "Number of numbers (Average)";
        }
    }

    /**
     * Computes the average number of lines that form part of comments
     * @param ASTNode
     * @return AVG number of lines of comments
     */
    @FunctionalInterface
    interface AVGNumberOfComments extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_COMMENTS";
        }
        @Override
        default String stringName()
        {
            return "Number of comments (Average)";
        }
    }

    @FunctionalInterface
    interface AVGNumberOfPeriods extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_PERIODS";
        }
        @Override
        default String stringName()
        {
            return "Number of periods (Average)";
        }
    }

    @FunctionalInterface
    interface AVGNumberOfCommas extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_COMMAS";
        }
        @Override
        default String stringName()
        {
            return "Number of commas (Average)";
        }
    }
    @FunctionalInterface
    interface AVGNumberOfSpaces extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_SPACES";
        }
        @Override
        default String stringName()
        {
            return "Number of spaces (Average)";
        }
    }
    @FunctionalInterface
    interface AVGNumberOfParenthesis  extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_PARENTHESIS";
        }
        @Override
        default String stringName()
        {
            return "Number of parenthesis (Average)";
        }
    }
    @FunctionalInterface
    interface AVGNumberOfComparisons extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_COMPARISONS";
        }
        @Override
        default String stringName()
        {
            return "Number of comparisons (Average)";
        }
    }
    @FunctionalInterface
    interface AVGNumberOfArithmaticOperations extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_ARITHMETIC_OPERATIONS";
        }
        @Override
        default String stringName()
        {
            return "Number of arithmetic operations (Average)";
        }
    }
    @FunctionalInterface
    interface AVGNumberOfAssignments extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_ASSIGNMENTS";
        }
        @Override
        default String stringName()
        {
            return "Number of assignments (Average)";
        }
    }
    @FunctionalInterface
    interface AVGNumberOfLoops extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_LOOPS";
        }
        @Override
        default String stringName()
        {
            return "Number of loops (Average)";
        }
    }
    @FunctionalInterface
    interface MAXInstancesOfChars extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "MAX_NUMBER_OF_CHARS";
        }
        @Override
        default String stringName()
        {
            return "Number of single characters (Max)";
        }
    }

    /* STRING INPUT METRICS:
     * STRING METRICS ARE SEGREGATED IN THEIR OWN TYPE SUCH THAT THEY CAN RECEIVE SOURCE-CODE DIRECTLY
     * INSTEAD OF TROUGH AN AST-NODE, DUE TO THE NEED OF LEXICAL PRESERVATION, WHICH IS NOT SUPPORTED BY JAVAPARSER
     */
    @FunctionalInterface
    interface AVGNumberOfBlankLines extends NamedMetricFunc {
        @Override
        Double apply(Node node, String sourceCode);
        @Override
        default String stringKey()
        {
            return "AVG_NUMBER_OF_BLANK_LINES";
        }
        @Override
        default String stringName()
        {
            return "Number of blank lines (Average)";
        }
    }
}
