package interfaces;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;

import java.util.Map;

public interface ProjectOverviewControllerIF {
    void updateProjectOverview(Project project, Map<PsiClass, Double> classScores);
}
