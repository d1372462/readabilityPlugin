package interfaces;

import com.intellij.psi.PsiClass;
import gui.MainToolWindowFactory;
import gui.fragments.ClassComponent;
import gui.fragments.SuggestionComponent;

public interface ActionListenerAssignerIF {
    void assign(MainToolWindowFactory guiComponent);

    void assign(ClassComponentIF component, PsiClass psiClass);

    void assign(SuggestionComponent component);

    void assign(ClassComponent classComponent, MainToolWindowControllerIF mainToolWindowController, PerClassTabControllerIF perClassTabController);
}
