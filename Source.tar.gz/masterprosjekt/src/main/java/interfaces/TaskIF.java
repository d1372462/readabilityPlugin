package interfaces;
@FunctionalInterface
public interface TaskIF {
    void doTask();
}
