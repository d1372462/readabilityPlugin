package interfaces;

import com.github.javaparser.ast.Node;

import java.util.List;
import java.util.function.BiFunction;

public interface MetricsAggregatorIF {
    List<BiFunction<Node,String,Double>> getAll();

    List<BiFunction<Node,String,Double>> getComplexityMeasures();

    List<BiFunction<Node,String,Double>> getIdentifierNamingMeasures();

    List<BiFunction<Node,String,Double>> getFormattingMeasures();

    List<BiFunction<Node,String,Double>> getCohesionMeasures();
}
