package interfaces;

import models.setModels.MetricsSnapshot;

import java.io.IOException;
import java.util.function.Consumer;

/**
 * Interface for catching and processing/storing the output of the metrics-snapshot background task
 */
@FunctionalInterface
public interface OutputCatcherIF extends Consumer<MetricsSnapshot> {
    @Override
     void accept(MetricsSnapshot snapshot);
}
