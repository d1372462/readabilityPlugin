package interfaces;

/**
 * General interface for factory-classes
 * @param <T>
 */
public interface FactoryIF<T,R> {
      R produce(T e);
}
