package interfaces;

import javax.swing.*;

public interface SuggestionIF {
     String getTitle();

     void setTitle(String title);

     String getDescription() ;

     void setDescription(String description);
}
