package interfaces;

import com.github.javaparser.ast.Node;

public interface NLPMetricsIF {

    @FunctionalInterface
    interface AVG_CIC extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "AVG_CIC";
        }
        @Override
        default String stringName()
        {
            return "Comment identifier consistency (Avergae)";
        }
    }

    @FunctionalInterface
    interface MAX_CIC extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "MAX_CIC";
        }
        @Override
        default String stringName()
        {
            return "Comment identifier consistency (Max)";
        }
    }


    @FunctionalInterface
    interface NMI_AVG extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "NMI_AVG";
        }
        @Override
        default String stringName()
        {
            return "Narrow-meaning identifiers (Average)";
        }
    }

    @FunctionalInterface
    interface TC_MIN extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "TC_MIN";
        }
        @Override
        default String stringName()
        {
            return "Textual Cohesion (Min)";
        }
    }

    @FunctionalInterface
    interface TC_MAX extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "TC_MAX";
        }
        @Override
        default String stringName()
        {
            return "Textual Cohesion (Max)";
        }
    }

    @FunctionalInterface
    interface CR_AVG extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "CR_AVG";
        }
        @Override
        default String stringName()
        {
            return "Comment Readability (Average)";
        }
    }

    @FunctionalInterface
    interface MAX_ITID extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "ITID_MAX";
        }
        @Override
        default String stringName()
        {
            return "Identifier Terms In Dictionary (Max)";
        }
    }

    @FunctionalInterface
    interface MIN_ITID extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "ITID_MIN";
        }
        @Override
        default String stringName()
        {
            return "Identifier Terms In Dictionary (MIN)";
        }
    }

    @FunctionalInterface
    interface AVG_ITID extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "ITID_AVG";
        }
        @Override
        default String stringName()
        {
            return "Identifier Terms In Dictionary (Average)";
        }
    }

    @FunctionalInterface
    interface AVG_NM extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "NM_AVG";
        }
        @Override
        default String stringName()
        {
            return "Number Of Meanings (Average)";
        }
    }

    @FunctionalInterface
    interface MAX_NM extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "NM_MAX";
        }
        @Override
        default String stringName()
        {
            return "Number Of Meanings (Max)";
        }
    }

    @FunctionalInterface
    interface AVG_TC extends NamedMetricFunc {
        @Override
        Double apply(Node node, String source);
        @Override
        default String stringKey()
        {
            return "TC_AVG";
        }
        @Override
        default String stringName()
        {
            return "Textual Cohesion (Average)";
        }
    }
}
