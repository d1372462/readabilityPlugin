package interfaces;

import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.PsiPackage;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface IDEAdapterIF {
    List<VirtualFile> getClassesInProject(Project project);

    List<PsiClass> getClassesInProject_Psi(Project project);

    Map<PsiClass,List<PsiMethod>> getMethodsInProject_Psi(Project project);

    Set<PsiPackage> getPackagesInProject(Project project);

    String virtualFileToString(VirtualFile file);

    VirtualFile getCurrentOpenFile(Project project);
}
