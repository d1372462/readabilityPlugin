package interfaces;

import java.util.Set;

public interface StringSetProvider {
    Set<String> extractWords();
}
