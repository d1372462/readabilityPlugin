package interfaces;

import com.intellij.ui.components.JBLabel;

import javax.swing.*;
import java.awt.*;

public interface SuggestionComponentIF {
     JLabel getSuggestionLabel();
     void setSuggestionLabel(JBLabel suggestionLabel);
     Font getDefaultFont();
     void setDefaultFont(Font defaultFont);
     JPanel getMidPanel();
     void setMidPanel(JPanel midPanel);
     SuggestionIF getSuggestion();
}
