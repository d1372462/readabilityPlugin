package interfaces;

import java.util.function.BiFunction;

public interface SuggestionFactoryIF extends FactoryIF<BiFunction, SuggestionIF> {
    SuggestionIF produce(BiFunction metricFunc);
}
