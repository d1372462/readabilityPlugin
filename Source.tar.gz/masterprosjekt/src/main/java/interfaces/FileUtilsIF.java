package interfaces;

public interface FileUtilsIF {
}
