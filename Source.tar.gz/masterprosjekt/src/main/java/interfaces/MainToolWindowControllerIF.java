package interfaces;

public interface MainToolWindowControllerIF {
    void selectTab(String tabName);
}
