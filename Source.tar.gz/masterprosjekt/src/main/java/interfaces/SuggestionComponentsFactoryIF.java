package interfaces;

import gui.fragments.SuggestionComponent;

public interface SuggestionComponentsFactoryIF extends FactoryIF<SuggestionIF, SuggestionComponent> {
    @Override
    SuggestionComponent produce(SuggestionIF suggestion);
}
