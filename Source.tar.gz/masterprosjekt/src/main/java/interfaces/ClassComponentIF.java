package interfaces;

import javax.swing.*;

public interface ClassComponentIF {

    JButton getClassLabelButton();

    JLabel getScoreLabel();
}
