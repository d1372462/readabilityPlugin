package interfaces;

import java.util.function.Consumer;

/**
 * Consumer for catching and processing exceptions
 */
public interface ExceptionCatcherIF extends Consumer<Exception> {
    @Override
     void accept(Exception exception);
}
