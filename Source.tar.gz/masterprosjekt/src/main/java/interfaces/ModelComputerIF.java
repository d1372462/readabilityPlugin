package interfaces;

import com.github.javaparser.ast.Node;
import metricsComputers.NLPMetrics;
import metricsComputers.StructuralMetrics;

public interface ModelComputerIF {


    /**
     * Computes a total readability score for a given class.
     * @param source-code as string
     * @param ASTNode of class
     * @param structuralMetrics
     * @param nlpMetrics
     * @return total readability score (double)
     */
     double computeTotalClassScore(String source,
                                         Node ASTNode);
     /**
      * Computes a total readability score from a metricsSnapshot instance.
      * @param source-code as string
      * @param ASTNode of class
      * @param structuralMetrics
      * @param nlpMetrics
      * @return total readability score (double)
      */
      double computeTotalClassScore(MetricsSnapshotIF metricsSnapshot);
}
