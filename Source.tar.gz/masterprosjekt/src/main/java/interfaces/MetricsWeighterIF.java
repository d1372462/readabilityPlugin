package interfaces;

import com.github.javaparser.ast.Node;

import java.util.HashMap;
import java.util.function.BiFunction;
import java.util.function.Function;

public interface MetricsWeighterIF {

    /**
     * Takes a given metric function as input, and returns a new function which produces a weighted
     * output of the given metric.  (Generic to infer function input type)
     * @param metricsFunc
     * @return Function with weighted output
     */
     BiFunction<Node, String,Double> weighted(BiFunction<Node, String,Double> metricsFunc);

    HashMap<BiFunction<Node, String, Double>, Double> getWeights();
}
