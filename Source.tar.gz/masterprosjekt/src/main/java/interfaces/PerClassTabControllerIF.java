package interfaces;

import com.intellij.psi.PsiClass;

import java.util.Comparator;
import java.util.Map;

public interface PerClassTabControllerIF {
    /**
     * Receives a MetricsSnapshot of measured metrics results,
     * and updates the metrics results table in the gui
     * (synchronized to avoid overlap execution)
     * @param metricsSnapshot
     */
     void addClassTab(String tabName, MetricsSnapshotIF metricsSnapshot);

     /**
     * Updates class-tabs with
     * @param metricsSnapshot
     * @param metricsMap
     */
     void updateClassTabs(final Map<PsiClass, MetricsSnapshotIF> metricsMap, MetricsAggregatorIF metricsAggregator);

    /**
     * Selects a class-tab (side-vertical) by tab-name
     * @param tabName
     */
     void selectTab(String tabName);

    /**
     * Aggregated method to update metrics tabs in gui
     * (facade method that calls other methods)
     * @param snapshotPerClass
     * @param metricsAggregator
     */
     void updateMetricsTabsGUI(Map<PsiClass, MetricsSnapshotIF> snapshotPerClass);

    /**
     * Setter for matrics tabs sort comparator
     * @param metricsTableSortComparator
     */
     void setMetricsTableSortComparator(Comparator<NamedMetricFunc> metricsTableSortComparator);

}
