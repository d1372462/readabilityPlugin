package interfaces;

import java.util.Date;
import java.util.Map;
import java.util.function.BiFunction;

public interface MetricsSnapshotIF {
     Date getSnapshotTime();

     Map<BiFunction, Double> getMetricsValues();

     Map<BiFunction, Double> getWeightedMetricsValues();

     /**
      * Calculates the average of metricsValues
      * @return metrics average (double)
      */
      double calcAverage();

     /**
      * Calculates the average of weightedMetricsValues
      * @return metrics average (double)
      */
      double calcWeightedAverage(MetricsWeighterIF weighter);
}
