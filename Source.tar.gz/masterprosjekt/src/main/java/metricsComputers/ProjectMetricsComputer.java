package metricsComputers;

import adapters.IDEAdapter;
import app.CurrentState;
import com.github.javaparser.ast.CompilationUnit;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import helperUtils.HashUtils;
import interfaces.IDEAdapterIF;
import interfaces.MetricsAggregatorIF;
import interfaces.MetricsSnapshotIF;
import interfaces.MetricsWeighterIF;
import models.ClassState;
import models.setModels.MetricsSnapshot;
import models.setModels.Tuple;
import parsing.ASTBuilder;
import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class ProjectMetricsComputer implements interfaces.ProjectMetricsComputerIF {
    private ASTBuilder astBuilder;
    private HashUtils hashUtils;
    private IDEAdapterIF ideAdapter;
    private MetricsAggregatorIF metricsAggregator;
    private MetricsWeighterIF metricsWeighter;
    private Consumer<Exception> errorConsumer;
    /**
     * Constructor for ProjectMetricsComputer receives a consumer to receive exceptions incurred during
     * computation
     * @param errorConsumer
     */
    public ProjectMetricsComputer(Consumer<Exception> errorConsumer, MetricsAggregatorIF metricsAggregator, MetricsWeighterIF metricsWeighter)
    {
        hashUtils = new HashUtils();
        astBuilder = new ASTBuilder();
        ideAdapter = new IDEAdapter();
        this.metricsAggregator = metricsAggregator;
        this.metricsWeighter = metricsWeighter;
        this.errorConsumer=errorConsumer;
    }

    /**
     * Returns existing in-memory MetricsResults for given class if not changed, else re-computes, updates in-memory,
     * and returns newly computed
     * @param class qualified-name (full class path... package+class)
     * @param sourceCode
     * @return MetricsResults for given class
     */
    @Override
    public MetricsSnapshot fetchOrCompute(String qualifiedName, String sourceCode)
    {
        // !! side-effect !!
        String currentHash = hashUtils.md5hash(sourceCode);
        // check if exists and equal:
        if (CurrentState.getInstance().getCurrentMetricsResults().containsKey(qualifiedName)
                && currentHash.equals(
                        CurrentState.getInstance().getCurrentMetricsResults().get(qualifiedName).getX().getHash()
        ))
        {
            // metrics-results exists and source-code is the same, return existing:
           return CurrentState.getInstance().getCurrentMetricsResults().get(qualifiedName).getY();
        }
        // does not exist, compute and update:
        MetricsSnapshot newCompute = computeAllOnSource(sourceCode);
        // update in-memory:
        CurrentState.getInstance().getCurrentMetricsResults().put(qualifiedName,new Tuple<>(new ClassState(qualifiedName, currentHash),newCompute));
        return newCompute;
    }

    /**
     * Computes all metrics on the given source-code representing a given class or compilation-unit
     * @param projClass
     * @return metricsSnapshot containing metrics measures
     */
    @Override
    public MetricsSnapshot computeAllOnSource(String sourceCodeString)
    {
        MetricsSnapshot snapshot = new MetricsSnapshot();
        try{
            CompilationUnit classAST = astBuilder.buildAST(sourceCodeString);
            // compute each metric on given classAST:
            metricsAggregator.getAll().stream().parallel().forEach(func ->{
                double metricValue = func.apply(classAST, sourceCodeString);
                snapshot.getMetricsValues().put(func,metricValue); // add metrics result
                if (metricsWeighter.getWeights().containsKey(func))
                {
                    snapshot.getWeightedMetricsValues().put(func, metricsWeighter.getWeights().get(func)*metricValue); // add weighted metric result
                }
            });
            // CREATE STREAM OF STRING-METRICS-FUNCTIONS (METRICS THAT MEASURE OVER THE SOURCE-CODE AS A STRING (FOR LEXICAL-PRESERVATION) HERE
        }catch(Exception e)
        {
            errorConsumer.accept(e);
        }
        return snapshot;
    }

    /**
     * Computes all metrics on all classes in a given project
     * and returns a map in the form class name -> MetricsSnapshot
     * @return map in the form class name -> MetricsSnapshot
     */
    @Override
    public Map<PsiClass, MetricsSnapshotIF> computeAllOnProject(Project project)
    {
       return computeAllOnClasses( // convert to tuple in the form PsiClass -> source_code string to make thread-safe
               ideAdapter.getClassesInProject_Psi(project).stream()
               .map(projClass -> new Tuple<>(projClass, projClass.getText()))
                .collect(Collectors.toList())
       );
    }

    /**
     * Computes all metrics on all classes in a given list of tuples (in the form class, source-code)
     * and returns a map in the form class name -> MetricsSnapshot
     * @return map in the form class name -> MetricsSnapshot
     */
    @Override
    public Map<PsiClass, MetricsSnapshotIF> computeAllOnClasses(List<Tuple<PsiClass, String>> classList)
    {
        Map<PsiClass,MetricsSnapshotIF> snapshotPerClass = Collections.synchronizedMap(new LinkedHashMap<>());
        try {
            classList.stream().parallel() // run metrics computation in parallel
                    .forEach(tuple -> snapshotPerClass.put(tuple.getX(),  fetchOrCompute(tuple.getX().getQualifiedName(), tuple.getY())  )); // add results to map
        }catch(Exception e){
            errorConsumer.accept(e);
        }
        return snapshotPerClass;
    }

    /**
     * Computes the average of all metrics for all classes in the given map
     * @param snapshotMaps
     * @return
     */
    @Override
    public MetricsSnapshot avgAll(Map<PsiClass, MetricsSnapshotIF> snapshotMaps)
    {
        MetricsSnapshot projectSnapshot = new MetricsSnapshot();
        Set<BiFunction> metricsFuncs = new LinkedHashSet<>();
        // gather metrics-function to average:
        snapshotMaps.values().stream().forEach(
               className -> className.getMetricsValues().keySet().stream().forEach(
                       metricsFunc -> metricsFuncs.add(metricsFunc))
        );
        // average all metrics-functions:
        metricsFuncs.stream().forEach(
                metricFunc -> {
                    OptionalDouble result = snapshotMaps.keySet().stream()
                            .mapToDouble(className -> snapshotMaps.get(className).getMetricsValues().get(metricFunc) == null ? 0 : // ensure measure exists for metric, else return 0
                                    snapshotMaps.get(className).getMetricsValues().get(metricFunc)) // map class to metrics result for specific metric for that class
                            .filter(value->  Double.isFinite(value) && (!Double.isNaN(value))) // keep only finite, non-nan numbers
                            .average(); // find project-wide average for the given metric
                    projectSnapshot.getMetricsValues().put(metricFunc, result.isPresent() ? result.getAsDouble() : 0); // insert into snapshot map
                });
        return projectSnapshot;
    }
}
