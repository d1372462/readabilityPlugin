package metricsComputers;
import com.github.javaparser.ast.Node;
import exceptions.WeightNotFoundException;
import interfaces.MetricsWeighterIF;
import java.util.HashMap;
import java.util.function.BiFunction;

/**
 * Responsible for weighting metrics functions according to findings by Buse et al.
 */
public class MetricsWeighter implements MetricsWeighterIF {

    private HashMap<BiFunction<Node,String, Double>, Double> weights;
    /**
     * Assigns metrics weights for weighted average
     *
     *
     * REPLACE AVERAGE WITH JUST PLAIN NUMBER (NO AVERAGE) --> REASON: INCREASED NUMBER OF LINES DILUTE THE RESULTS IN AVERAGE!
     */
    public MetricsWeighter(StructuralMetrics structuralMetrics, NLPMetrics nlpMetrics)
    {
        this.weights = new HashMap<>();
        // add weights:
        weights.put(structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC, -0.6905);
        weights.put(structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC,-0.0468);
        weights.put(structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC,-0.0638 );
        weights.put(structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC, -0.2071);
        weights.put(structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER, -0.1573);
        weights.put(structuralMetrics.AVG_NUMBER_OF_PERIODS,-0.1892);
        weights.put(structuralMetrics.AVG_NUMBER_OF_COMPARISONS,-0.2936);
        weights.put(structuralMetrics.AVG_LINE_LENGTH_FUNC,0.0065);
        weights.put(structuralMetrics.MAX_LINE_LENGTH_FUNC,-0.003);
        weights.put(structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC,-0.145);
        weights.put(structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC,0.1775);
        weights.put(structuralMetrics.MAX_INSTANCES_OF_CHARS,0.0064);
        weights.put(nlpMetrics.TC_MAX,-0.8977 );
        weights.put(nlpMetrics.TC_MIN,-2.2382);
        weights.put(nlpMetrics.AVG_TC,3.043);
        weights.put(nlpMetrics.MAX_NM,-0.0221);
    }

    @Override
    public BiFunction<Node,String,Double> weighted(BiFunction<Node,String,Double> metricsFunc)
    {
        if (weights.get(metricsFunc) == null)
        {
            throw new WeightNotFoundException("Weight not found for given function - " +
                    "Make sure metrics instance is the same as supplied to weighter constructor");
        }
        return (node,source) -> weights.get(metricsFunc) * metricsFunc.apply(node,source); // else return positive value
    }

    public HashMap<BiFunction<Node, String, Double>, Double> getWeights() {
        return weights;
    }

    public void setWeights(HashMap<BiFunction<Node,String, Double>, Double> weights) {
        this.weights = weights;
    }
}