package metricsComputers;

import helperUtils.StrUtils;

import java.util.Comparator;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;

/**
 * Contains constant helper functions to form part of metrics calculations
 * (sub-routines)
 */
public class HelperFunctions {
    private StrUtils strUtils;

    public HelperFunctions()
    {
        this.strUtils = new StrUtils();
    }
    /**
     * Counts number of occurrences of numbers in given string
     * @param str
     * @return number of numbers in given string
     */
    public final ToIntFunction<String> numberOfNumbers = str ->
            (int)str.chars()
                    .mapToLong(ch -> Character.isDigit(ch) ? 1 : 0 )
                    .sum();

    /**
     * Counts the max occurance of any given character in the string
     * @param str
     * @return
     */
    public final ToIntFunction<String> maxInstancesOfChars = str ->
    {
        Optional<Integer> max = strUtils.countInstancesOfCharacters(str).values().stream()
                .max(Comparator.naturalOrder());
        return max.isPresent() ? max.get() : 0;
    };


    /**
     * Counts the average occurance of any given character in the string
     * @param str
     * @return
     */
    public final ToDoubleFunction<String> AVGInstancesOfChars = str->
    {
        OptionalDouble avg = strUtils.countInstancesOfCharacters(str).values().stream()
                .mapToDouble(charCount -> (double)charCount)
                .average();
        return avg.isPresent() ? avg.getAsDouble() : 0;
    };




    /**
     * Counts number of indents in line
     * @param line
     * @return
     */
    public final ToIntFunction<String> numberOfIndentsInLine = line ->
    line.startsWith("\t") ?
                strUtils.countInstancesOfSubstr(line,"\t") : // if indent is tabs, count tabs
                strUtils.countInstancesOfSubstr(line,"    "); // else, assumes 4 spaces = 1 indent and count space-chunks

}
