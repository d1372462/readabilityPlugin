package metricsComputers;

import com.github.javaparser.ast.Node;
import interfaces.MetricsSnapshotIF;
import interfaces.ModelComputerIF;

public class ModelComputer implements ModelComputerIF {
    private StructuralMetrics structuralMetrics;
    private NLPMetrics nlpMetrics;

    public ModelComputer(
            StructuralMetrics structuralMetrics,
             NLPMetrics nlpMetrics)
    {
        this.structuralMetrics = structuralMetrics;
        this.nlpMetrics = nlpMetrics;
    }
    /**
     * Computes a total readability score from a metricsSnapshot instance.
     * @param source-code as string
     * @param ASTNode of class
     * @param structuralMetrics
     * @param nlpMetrics
     * @return total readability score (double)
     */
    public double computeTotalClassScore(MetricsSnapshotIF metricsSnapshot)
    {
        /*
        return
                        -0.9207 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC) +
                        -0.0638 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC) +
                        -0.0636 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC) +
                        -0.1469 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC) +
                        -0.1376 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER) +
                        -0.2413 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_PERIODS) +
                        -0.2134 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_COMMAS) +
                         0.831  * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_PARENTHESIS) +
                        -0.3088 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_COMPARISONS) +
                        -0.4769 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_ASSIGNMENTS) +
                         0.0085 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_LINE_LENGTH_FUNC) +
                        -0.003  * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_LINE_LENGTH_FUNC) +
                        -0.1452 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC) +
                         0.1765 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC)+
                         0.0053 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_INSTANCES_OF_CHARS) +
                        -0.9672 * metricsSnapshot.getMetricsValues().get(nlpMetrics.TC_MAX) +
                        -2.7323 * metricsSnapshot.getMetricsValues().get(nlpMetrics.TC_MIN) +
                         3.5481 * metricsSnapshot.getMetricsValues().get(nlpMetrics.AVG_TC) +
                         0.1366 * metricsSnapshot.getMetricsValues().get(nlpMetrics.MIN_ITID) +
                         1.4448 * metricsSnapshot.getMetricsValues().get(nlpMetrics.MAX_CIC) +
                         5.471;
                         */

        return
                -0.6905 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC) +
            -0.0468 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC) +
            -0.0638 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC) +
            -0.2071 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC) +
            -0.1573 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER)  +
            -0.1892 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_PERIODS) +
            -0.2936 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_COMPARISONS) +
            0.0065 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_LINE_LENGTH_FUNC) +
            -0.003  * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_LINE_LENGTH_FUNC) +
            -0.145  * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC) +
            0.1775 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC) +
            0.0064 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_INSTANCES_OF_CHARS) +
            -0.8977 * metricsSnapshot.getMetricsValues().get(nlpMetrics.TC_MAX) +
            -2.2382 * metricsSnapshot.getMetricsValues().get(nlpMetrics.TC_MIN)  +
            3.043  * metricsSnapshot.getMetricsValues().get(nlpMetrics.AVG_TC) +
            -0.0221 * metricsSnapshot.getMetricsValues().get(nlpMetrics.MAX_NM) +
            5.632;
    }


    /**
     * Computes a total readability score for a given class.
     * @param source-code as string
     * @param ASTNode of class
     * @param structuralMetrics
     * @param nlpMetrics
     * @return total readability score (double)
     */
    public double computeTotalClassScore(String source,
                                         Node ASTNode)
    {
        return
                -0.6905 * structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC.apply(ASTNode, source) +
                        -0.0468 * structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC.apply(ASTNode, source) +
                        -0.0638 * structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC.apply(ASTNode, source) +
                        -0.2071 * structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC.apply(ASTNode, source) +
                        -0.1573 * structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER.apply(ASTNode, source) +
                        -0.1892 * structuralMetrics.AVG_NUMBER_OF_PERIODS.apply(ASTNode, source) +
                        -0.2936 * structuralMetrics.AVG_NUMBER_OF_COMPARISONS.apply(ASTNode, source) +
                        0.0065 * structuralMetrics.AVG_LINE_LENGTH_FUNC.apply(ASTNode, source) +
                        -0.003  * structuralMetrics.MAX_LINE_LENGTH_FUNC.apply(ASTNode, source) +
                        -0.145  * structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC.apply(ASTNode, source) +
                        0.1775 * structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC.apply(ASTNode, source) +
                        0.0064 * structuralMetrics.MAX_INSTANCES_OF_CHARS.apply(ASTNode, source) +
                        -0.8977 * nlpMetrics.TC_MAX.apply(ASTNode, source) +
                        -2.2382 * nlpMetrics.TC_MIN.apply(ASTNode, source) +
                        3.043  * nlpMetrics.AVG_TC.apply(ASTNode, source) +
                        -0.0221 * nlpMetrics.MAX_NM.apply(ASTNode, source) +
                        5.632;
    }

}
