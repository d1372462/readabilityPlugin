package metricsComputers;
import com.github.javaparser.ast.Node;
import interfaces.MetricsAggregatorIF;
import interfaces.MetricsSnapshotIF;
import interfaces.MetricsWeighterIF;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MetricsAggregator implements MetricsAggregatorIF {
    private NLPMetrics nlpMetrics;
    private StructuralMetrics structuralMetrics;

    public MetricsAggregator(StructuralMetrics structuralMetrics, NLPMetrics nlpMetrics)
    {
        this.structuralMetrics = structuralMetrics;
        this.nlpMetrics  = nlpMetrics;
    }

    /**
     * Returns a list of all node-input metrics (metrics computed from an AST node)
     * @return List of node-input metrics
     */
    @Override
    public List<BiFunction<Node,String,Double>> getAll()
    {
        List<BiFunction<Node,String,Double>> metricsFuncs = new LinkedList<>();
        metricsFuncs.addAll(structuralMetrics.getAll());
        metricsFuncs.addAll(nlpMetrics.getAll());
        return metricsFuncs;
    }

    // CATEGORIES:

    /**
     * Returns a list of all complexty-node metrics
     * @return list of structural metrics
     */
    @Override
    public List<BiFunction<Node,String,Double>> getComplexityMeasures()
    {
        return Arrays.stream(new BiFunction[]{
                structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC,
                structuralMetrics. MAX_NUMBER_OF_IDENTIFIERS_FUNC,
                structuralMetrics. AVG_NUMBER_OF_IDENTIFIERS_FUNC,
                structuralMetrics. MAX_OCCURRENCE_OF_IDENTIFIER,
                structuralMetrics. AVG_NUMBER_OF_PERIODS,
                structuralMetrics. AVG_NUMBER_OF_COMPARISONS
        })
                .map(func -> (BiFunction<Node, String, Double>) func) // cannot initialize generic array, therefore, map each object here
                .collect(Collectors.toList());
    }

    /**
     * Returns a list of all complexty-node metrics
     * @return list of structural metrics
     */
    @Override
    public List<BiFunction<Node,String,Double>> getCohesionMeasures()
    {
        return Arrays.stream(new BiFunction[]{
                nlpMetrics.TC_MAX,
                nlpMetrics.TC_MIN,
                nlpMetrics.AVG_TC
        })
                .map(func -> (BiFunction<Node, String, Double>) func) // cannot initialize generic array, therefore, map each object here
                .collect(Collectors.toList());
    }

    /**
     * Returns a list of all identifier-naming-node metrics
     * @return list of structural metrics
     */
    @Override
    public List<BiFunction<Node,String,Double>> getIdentifierNamingMeasures()
    {
        return Arrays.stream(new BiFunction[]{
                structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC,
                structuralMetrics. MAX_INSTANCES_OF_CHARS,
        })
                .map(func -> (BiFunction<Node,String,Double>) func) // cannot initialize generic array, therefore, map each object here
                .collect(Collectors.toList());
    }

    /**
     * Returns a list of all formatting-node metrics
     * @return list of structural metrics
     */
    @Override
    public List<BiFunction<Node,String,Double>> getFormattingMeasures()
    {
        return Arrays.stream(new BiFunction[]{
                structuralMetrics.AVG_LINE_LENGTH_FUNC,
                structuralMetrics.MAX_LINE_LENGTH_FUNC,
                structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC,
                structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC
        })
                .map(func -> (BiFunction<Node,String,Double>) func) // cannot initialize generic array, therefore, map each object here
                .collect(Collectors.toList());
    }
}
