package metricsComputers;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.nodeTypes.NodeWithIdentifier;
import com.github.javaparser.ast.stmt.*;
import extractors.ASTExtractor;
import helperUtils.ASTUtils;
import helperUtils.NumUtils;
import helperUtils.StrUtils;
import interfaces.StructuralMetricsIF;
import models.Identifier;
import org.codehaus.groovy.ast.expr.DeclarationExpression;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Contains functional constants for computing structural metrics
 * (stored as functions rather than being methods in order to be able to
 * refer the functions themselves)
 */
public class StructuralMetrics {

    private StrUtils strUtils;
    private ASTUtils astUtils;
    private ASTExtractor astExtractor;
    private NumUtils numUtils;
    private HelperFunctions helperFunctions;

    public StructuralMetrics()
    {
        strUtils = new StrUtils();
        astUtils = new ASTUtils();
        astExtractor = new ASTExtractor();
        numUtils = new NumUtils();
        helperFunctions = new HelperFunctions();
    }

    /**
     * Returns a list of all structural metrics
     * @return list of structural metrics
     */
    public List<BiFunction<Node,String,Double>> getAll()
    {
        return Arrays.stream(new BiFunction[]{
                AVG_CYCLOMATIC_COMPLEXITY_FUNC,
                MAX_NUMBER_OF_IDENTIFIERS_FUNC,
                AVG_IDENTIFIER_LENGTH_FUNC,
                AVG_NUMBER_OF_IDENTIFIERS_FUNC,
                MAX_OCCURRENCE_OF_IDENTIFIER,
                AVG_NUMBER_OF_PERIODS,
                AVG_NUMBER_OF_COMPARISONS,
                AVG_LINE_LENGTH_FUNC,
                MAX_LINE_LENGTH_FUNC,
                MAX_NUMBER_OF_INDENTS_FUNC,
                AVG_NUMBER_OF_INDENTS_FUNC,
                MAX_INSTANCES_OF_CHARS
        })
                .map(func -> (BiFunction<Node,String,Double>) func) // cannot initialize generic array, therefore, map each object here
                .collect(Collectors.toList());
    }


    /**
     * Computes Cyclomatic Complexity for given parse node
     * (Number of conditional branches)
     * (Private to avoid external exposure, as it is only used internally to calculate average cc)
     * @param  Node from abstract syntax tree
     */
    private final StructuralMetricsIF.CyclomaticComplexityFunc CYCLOMATIC_COMPLEXITY_FUNC = (ASTNode, sourceCode) -> (double) (
            // if, else if, and else branches:
            ASTNode.findAll(IfStmt.class).stream() // find all if-statements (including else-if)
                    .mapToLong(branch -> 1 + // count if branches as 1, then count it's else branch as 1 if present:
                            (branch.getElseStmt().isPresent() ? ( branch.getElseStmt().get() instanceof IfStmt ? 0 : 1) : 0 ))
                    .sum() + // switch-cases:
                    ASTNode.findAll(SwitchStmt.class).stream()
                            .mapToLong(branch -> branch.getEntries().size()) // count only "case" statements, not switch itself...
                            .sum() );

    /**
     * Computes the average branching factor
     * @param ASTNode
     * @return AVG branching
     */
    public final StructuralMetricsIF.AVGCyclomaticComplexityFunc AVG_CYCLOMATIC_COMPLEXITY_FUNC = (ASTNode, source) ->
            numUtils.safeDivide(
                    CYCLOMATIC_COMPLEXITY_FUNC.apply(ASTNode, source),
                    strUtils.lineCount(source)
            );

    /**
     * Computes the max number of identifiers per line
     * @param ASTNode
     * @return max number of identifiers on single line
     *
     *   !! TO BE TESTED !!
     */
    public final StructuralMetricsIF.MaxNumberOfIdentifiersFunc MAX_NUMBER_OF_IDENTIFIERS_FUNC = (ASTNode, source) ->{
        Map<Integer, Integer> lineIdentifierCounts = new HashMap<>(); // group lines by identifier count
        astExtractor.extractIdentifiers(ASTNode).stream()
                .forEach(identifier ->
                        lineIdentifierCounts.put(
                                identifier.getRange().get().begin.line,
                                lineIdentifierCounts.get(identifier.getRange().get().begin.line) == null ? 1 :
                                        lineIdentifierCounts.get(identifier.getRange().get().begin.line)+1
                        ));
        OptionalDouble result = lineIdentifierCounts.values().stream().mapToDouble(lineCount -> (double)lineCount).max();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Computes the average identifier length of all identifiers from node (recurcive)
     * @param ASTNode
     * @return
     */
    public final StructuralMetricsIF.AVGIdentifierLengthFunc AVG_IDENTIFIER_LENGTH_FUNC = (ASTNode, source) ->
            astExtractor.extractIdentifiers(ASTNode).stream()
                    .mapToInt(identifier -> identifier.getName().length())
                    .average().getAsDouble();

    /**
     * Computes the max identifier length of any identifiers from node (recurcive)
     * @param ASTNode
     * @return Max Identifier length
     */
    public final StructuralMetricsIF.MaxIdentifierLengthFunc MAX_IDENTIFIER_LENGTH = (ASTNode, source) -> {
        OptionalInt result = astExtractor.extractIdentifiers(ASTNode).stream()
                .mapToInt(identifier -> identifier.getName().length())
                .max();
        return result.isPresent() ? (double)result.getAsInt() : 0;
    };

    /**
     * Counts number of identifiers from given ASTNode
     * @param ASTNode
     * @return number of identifiers
     */
    public final StructuralMetricsIF.AVGNumberOfIdentifiersFunc AVG_NUMBER_OF_IDENTIFIERS_FUNC = (ASTNode, source) ->
            numUtils.safeDivide(
                    astExtractor.extractIdentifiers(ASTNode).size(),
                    strUtils.lineCount(source)
            );

    /**
     * Max number of single identifier measure
     * @param ASTNode
     * @return number of identifiers
     */
    public final StructuralMetricsIF.MaxOccurrenceOfIdentifier MAX_OCCURRENCE_OF_IDENTIFIER = (ASTNode, source) ->{
        Map<Node,Integer> occurrenceMap = new HashMap<>();
        ASTNode.findAll(VariableDeclarator.class).stream()
                .map(var -> var.getName()) // get identifier name
                .forEach(var ->
                        occurrenceMap.put(var, occurrenceMap.get(var) == null ? 1 : occurrenceMap.get(var)+1)
                );
        OptionalDouble result = occurrenceMap.values().stream().mapToDouble(var -> (double)var).max();
        return result.isPresent() ? result.getAsDouble() : 0 ;
    };

    /**
     * Counts the max number of instances of a number in any given line in the AST node
     * sub-tree
     * @param ASTNode to measure
     * @return double avg instances of any single char in all lines of the given ast node
     */
    public final StructuralMetricsIF.MaxNumberOfNumbers MAX_NUMBER_OF_NUMBERS = (ASTNode, source)-> {
        OptionalInt result = astUtils.ASTNodeToLines(astExtractor.stripComments(ASTNode.clone())).stream().parallel()
                .mapToInt(helperFunctions.numberOfNumbers)
                .max();
        return result.isPresent() ? (double)result.getAsInt() : 0;
    };

    /**
     * Counts the average number of instances of a number in lines of the AST node
     * sub-tree
     * @param ASTNode to measure
     * @return double avg instances of any single char in all lines of the given ast node
     */
    public final StructuralMetricsIF.AVGNumberOfNumbers AVG_NUMBER_OF_NUMBERS = (ASTNode, source)-> {
        OptionalDouble result =  astUtils.ASTNodeToLines(astExtractor.stripComments(ASTNode.clone())).stream()
                .mapToInt(helperFunctions.numberOfNumbers)
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Computes the average number of lines that form part of comments
     * @param ASTNode
     * @return AVG number of lines of comments
     */
    public final StructuralMetricsIF.AVGNumberOfComments AVG_NUMBER_OF_COMMENTS = (ASTNode, source)->
    numUtils.safeDivide(
                ASTNode.getAllContainedComments().stream()
                        .mapToInt(comment-> astUtils.ASTNodeToLines(comment).size())
                        .sum() ,
                strUtils.lineCount(source));


    // AVG COUNTS  - WARNING THE FOLLOWING MEASURES SHOULD IGNORE COMMENTS (DOES NOT AT THE MOMENT) !! TO BE IMPROVED !!
    public final StructuralMetricsIF.AVGNumberOfPeriods AVG_NUMBER_OF_PERIODS = (ASTNode, source)-> {
        OptionalDouble result = strUtils.stringToLines(source).stream().parallel()
                .mapToDouble( line -> strUtils.countInstancesOfSubstr(line,"."))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    public final StructuralMetricsIF.AVGNumberOfCommas AVG_NUMBER_OF_COMMAS = (ASTNode, source)-> {
        OptionalDouble result = strUtils.stringToLines(source).stream()
                .mapToDouble( line -> strUtils.countInstancesOfSubstr(line,","))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    public final StructuralMetricsIF.AVGNumberOfSpaces AVG_NUMBER_OF_SPACES = (ASTNode, source)-> {
        OptionalDouble result = strUtils.stringToLines(source).stream()
                .mapToDouble( line -> strUtils.countInstancesOfSubstr(line," "))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    public final StructuralMetricsIF.AVGNumberOfParenthesis AVG_NUMBER_OF_PARENTHESIS = (ASTNode, source)-> {
        OptionalDouble result = strUtils.stringToLines(source).stream()
                .mapToDouble( line -> strUtils.countInstancesOfSubstr(line,":"))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    public final StructuralMetricsIF.AVGNumberOfComparisons AVG_NUMBER_OF_COMPARISONS = (ASTNode, source)-> {
        OptionalDouble result = strUtils.stringToLines(source).stream()
                .mapToDouble( line -> strUtils.countInstancesOfSubstr(line,new String[]{"==","!=",">","<"}))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    // END OF: WARNING THE FOLLOWING MEASURES SHOULD IGNORE COMMENTS (DOES NOT AT THE MOMENT) !! TO BE IMPROVED !!
    public final StructuralMetricsIF.AVGNumberOfAssignments AVG_NUMBER_OF_ASSIGNMENTS = (ASTNode, source)-> {
       return numUtils.safeDivide(
                ASTNode.findAll(AssignExpr.class).size() +
                        + ASTNode.findAll(VariableDeclarationExpr.class).size()
                        + ASTNode.findAll(FieldDeclaration.class).stream().filter(field -> field.findAll( Expression.class).size()>0).count(),
                strUtils.lineCount(source)
        );
    };

    public final StructuralMetricsIF.AVGNumberOfLoops AVG_NUMBER_OF_LOOPS = (ASTNode, source)->
            numUtils.safeDivide(
                    ASTNode.findAll(WhileStmt.class).stream().count() // while loops
                            + ASTNode.findAll(ForStmt.class).stream().count() // for loops
                            + ASTNode.findAll(ForeachStmt.class).stream().count(), // contracted/ simplified for loops
                    strUtils.lineCount(source)
            );

    public final StructuralMetricsIF.AVGNumberOfArithmaticOperations AVG_NUMBER_OF_ARITHMATIC_OPERATIONS = (ASTNode, source) -> {
        OptionalDouble result = astUtils.ASTNodeToLines(astExtractor.stripComments(ASTNode.clone())).stream()
                .mapToDouble( line -> strUtils.countInstancesOfSubstr(line.
                                replace("++","").replace("--",""), // remove decrement and increment before count
                        new String[]{"-","+","*","/","%"})) // count arithmatic operations
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    // STRING INPUT MEASURES:
    public final StructuralMetricsIF.AVGNumberOfBlankLines AVG_NUMBER_OF_BLANK_LINES = (ASTNode, source)-> {
        OptionalDouble result = strUtils.stringToLines(source).stream().
                mapToDouble(line -> line.trim().isEmpty() ? 1 : 0)
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Computes the average line-length of given ASTNode when converted to code
     * @param ASTNode
     * @return
     */
    public final StructuralMetricsIF.AVGLineLengthFunc AVG_LINE_LENGTH_FUNC = (ASTNode, source) ->
            strUtils.stringToLines(source).stream()
                    .mapToInt(line -> line.trim().length())
                    .average().getAsDouble();

    /**
     * Finds the length of the longest line in the ASTNode when converted to code
     *
     * NOTE: MUST RECEIVE LEXICALLY-PRESERVED SOURCE-CODE (READ DIRECTLY FROM FILE OR EDITOR) INSTEAD OF
     * RECEIVING AN AST-NODE ...
     *
     * @param ASTNode
     * @return
     */
    public final StructuralMetricsIF.MaxLineLengthFunc MAX_LINE_LENGTH_FUNC =  (ASTNode, source) ->{
        OptionalInt result = strUtils.stringToLines(source).stream()
                .mapToInt(line -> line.trim().length())
                .max();
        return  result.isPresent() ? (double)result.getAsInt() : 0;
    };

    /**
     * Counts the max number of indents in any given line from AST node
     * @param ASTNode
     * @return MAX number of indents
     */
    public final StructuralMetricsIF.MaxNumberOfIndentsFunc MAX_NUMBER_OF_INDENTS_FUNC = (ASTNode, source) -> {
        OptionalInt result = strUtils.stringToLines(source).stream().parallel()
                .mapToInt(helperFunctions.numberOfIndentsInLine)
                .max();
        return result.isPresent() ? (double)result.getAsInt() : 0;
    };

    /**
     * Counts the max number of indents in any given line from AST node
     * @param ASTNode
     * @return MAX number of indents
     */
    public final StructuralMetricsIF.AVGNumberOfIndentsFunc AVG_NUMBER_OF_INDENTS_FUNC = (ASTNode, source) -> {
        OptionalDouble result = strUtils.stringToLines(source).stream().parallel()
                .mapToInt(helperFunctions.numberOfIndentsInLine)
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Counts the max occurance of any given character in the AST Node
     * @param ASTNode to measure
     * @return double max instances of any single char in all lines of the given ast node
     */
    public final StructuralMetricsIF.MaxInstancesOfChars MAX_INSTANCES_OF_CHARS = (ASTNode, source) -> {
        OptionalInt result = strUtils.stringToLines(source
                .replace(" ","") // remove blank space
        ).stream()
                .mapToInt(helperFunctions.maxInstancesOfChars)
                .max();
        return result.isPresent() ? (double)result.getAsInt() : 0;
    };
}