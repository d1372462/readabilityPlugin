package metricsComputers;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.representqueens.lingua.en.Fathom;
import com.representqueens.lingua.en.Readability;
import adapters.WordNetAdapter;
import extractors.ASTExtractor;
import helperUtils.ASTUtils;
import helperUtils.NLPUtils;
import helperUtils.NumUtils;
import helperUtils.SetUtils;
import interfaces.NLPMetricsIF;

import java.util.*;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

public class NLPMetrics {
    private Set<String> defaultDictionary;
    private NLPUtils nlpUtils;
    private SetUtils setUtils;
    private NumUtils numUtils;
    private ASTUtils astUtils;
    private ASTExtractor astExtractor;

    public NLPMetrics()
    {
        defaultDictionary = new HashSet<String>();
        nlpUtils = new NLPUtils();
        setUtils = new SetUtils();
        numUtils = new NumUtils();
        astUtils = new ASTUtils();
        astExtractor = new ASTExtractor();
    }

    public NLPMetrics(Set<String> defaultDictionary)
    {
        this();
        this.defaultDictionary = defaultDictionary;
    }

    /**
     * Returns a list of all nlp node-input-metrics
     * @return list of nlp metrics
     */
    public List<BiFunction<Node,String,Double>> getAll()
    {
        return Arrays.stream(new BiFunction[]{
                TC_MAX,
                TC_MIN,
                AVG_TC,
                MAX_NM
        })
                .map(func -> (BiFunction<Node,String,Double>) func) // // cannot initialize generic array, therefore, map each object here
                .collect(Collectors.toList());
    }

    /**
     * Computes the average ITID of all methods of a given AST node (sub-tree)
     * (WARNING: Does not compute per line)
     * @param identifierTextNodes
     * @return metricsComputers result (fraction of overlap)
     */
    public final NLPMetricsIF.MIN_ITID MIN_ITID = (ASTNode,source) ->
    {
        OptionalDouble result =  ASTNode.findAll(MethodDeclaration.class).stream().mapToDouble(
               method-> computeITID(astExtractor.extractIdentifiers(method.findFirst(BlockStmt.class).get()).stream().parallel()
                        .flatMap(identifier -> nlpUtils.tokenizeIdentifier(identifier.getName()).stream()) // toekanize identifyer (extract terms in case of camel-case)
                        .map(nlpUtils::normalize) // normalize each term
                        .collect(Collectors.toSet()))
        ).min();
        return result.isPresent() ? result.getAsDouble() : 0;
    };


    /**
     * Computes the average ITID of all methods of a given AST node (sub-tree)
     * (WARNING: Does not compute per line)
     * @param identifierTextNodes
     * @return metricsComputers result (fraction of overlap)
     */
    public final NLPMetricsIF.AVG_ITID AVG_ITID = (ASTNode,source) ->
    {
        OptionalDouble result =  ASTNode.findAll(MethodDeclaration.class).stream().mapToDouble(
                method-> computeITID(astExtractor.extractIdentifiers(method.findFirst(BlockStmt.class).get()).stream().parallel()
                        .flatMap(identifier -> nlpUtils.tokenizeIdentifier(identifier.getName()).stream()) // toekanize identifyer (extract terms in case of camel-case)
                        .map(nlpUtils::normalize) // normalize each term
                        .collect(Collectors.toSet()))
        ).average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Computes the max ITID of all methods of a given AST node (sub-tree)
     * (WARNING: Does not compute per line)
     * @param identifierTextNodes
     * @return metricsComputers result (fraction of overlap)
     */
    public final NLPMetricsIF.MAX_ITID MAX_ITID = (ASTNode,source) ->
    {
        OptionalDouble result =  ASTNode.findAll(MethodDeclaration.class).stream()
                .mapToDouble(
                method-> computeITID(astExtractor.extractIdentifiers(method.findFirst(BlockStmt.class).get()).stream().parallel()
                        .flatMap(identifier -> nlpUtils.tokenizeIdentifier(identifier.getName()).stream()) // toekanize identifyer (extract terms in case of camel-case)
                        .map(nlpUtils::normalize) // normalize each term
                        .collect(Collectors.toSet()))
        ).max();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Measures the textual-cohesion (TC) of all the control-statements found in the given
     * ast-subtree.  The cartesian product of the set of all control-statements in the sub-tree is used
     * to compute the TC of each pair of control-statements, and
     */
    public final NLPMetricsIF.AVG_TC AVG_TC = (ASTNode,source) ->
    {
        Set<Node> controlStatements =  astExtractor.stripControlStatements( // strip inner control-statements from control-statements (control-statements inside other control-statements) to avoid duplicate comparison
                astExtractor.extractControlStatements(ASTNode.clone())
        );

        OptionalDouble result=
                setUtils.allPairs(controlStatements).stream()
                        .parallel()
                        .filter(tuple -> ! tuple.getX().equals(tuple.getY())) // remove pairs where X == Y
                        // .forEach(p -> System.out.println("#########"+System.lineSeparator()+p.getX()+System.lineSeparator()+"------------"+System.lineSeparator()+p.getY()+System.lineSeparator()+System.lineSeparator()));
                        .mapToDouble(controlStmTuple -> computeTC(controlStmTuple.getX(),controlStmTuple.getY())) // compute TC over the tuple
                        .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Measures the textual-cohesion (TC) of all the control-statements found in the given
     * ast-subtree.  The cartesian product of the set of all control-statements in the sub-tree is used
     * to compute the TC of each pair of control-statements, and
     */
    public final NLPMetricsIF.TC_MAX TC_MAX = (ASTNode,source) ->
    {
        Set<Node> controlStatements =  astExtractor.stripControlStatements( // strip inner control-statements from control-statements (control-statements inside other control-statements) to avoid duplicate comparison
                astExtractor.extractControlStatements(ASTNode.clone())
        );

        OptionalDouble result=
                setUtils.allPairs(controlStatements).stream().parallel()
                        .filter(tuple -> ! tuple.getX().equals(tuple.getY())) // remove pairs where X == Y
                        // .forEach(p -> System.out.println("#########"+System.lineSeparator()+p.getX()+System.lineSeparator()+"------------"+System.lineSeparator()+p.getY()+System.lineSeparator()+System.lineSeparator()));
                        .mapToDouble(controlStmTuple -> computeTC(controlStmTuple.getX(),controlStmTuple.getY())) // compute TC over the tuple
                        .max();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Measures the average number of meanings for all words in the subtree (words extracted from identifiers)
     */
    public final NLPMetricsIF.AVG_NM AVG_NM = (ASTNode,source) ->
    {
        OptionalDouble result = astExtractor.extractIdentifiers(ASTNode).stream().parallel()
                .flatMap(identifier -> nlpUtils.tokenizeIdentifier(identifier.getName()).stream())
                .map(token -> nlpUtils.normalize(token))
                .map(token -> WordNetAdapter.getWord(token)) // NOTE: POS-ANALYSIS SHOULD BE USED TO DETERMINE POS CATEGORY, ELSE FIND A WAY TO NOT HAVE TO SPECIFY POS CATEGORY... CURRENTLY ONLY WORKS WITH NOUNS SINCE NON-NOUNS WILL BE NULL, AND FILTERED OUT (NOT INCLUDED IN METRIC MEASURE)
                .filter(word -> word != null) // only keep non-null words
                .mapToInt(word -> word.getSynset().getWords().size())
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Measures the average number of meanings for all words in the subtree (words extracted from identifiers)
     */
    public final NLPMetricsIF.MAX_NM MAX_NM = (ASTNode,source) ->
    {
        OptionalInt result = astExtractor.extractIdentifiers(ASTNode).stream().parallel()
                .flatMap(identifier -> nlpUtils.tokenizeIdentifier(identifier.getName()).stream())
                .map(token -> nlpUtils.normalize(token))
                .map(token -> WordNetAdapter.getWord(token)) // NOTE: POS-ANALYSIS SHOULD BE USED TO DETERMINE POS CATEGORY, ELSE FIND A WAY TO NOT HAVE TO SPECIFY POS CATEGORY... CURRENTLY ONLY WORKS WITH NOUNS SINCE NON-NOUNS WILL BE NULL, AND FILTERED OUT (NOT INCLUDED IN METRIC MEASURE)
                .filter(word -> word != null) // only keep non-null words
                .mapToInt(word -> word.getSynset().getWords().size())
                .max();
        return result.isPresent() ? (double)result.getAsInt() : 0;
    };

    /**
     * Computes the average CIC of all methods of a given AST node (sub-tree)
     * @param identifierTextNodes
     * @return metricsComputers result (fraction of overlap)
     */
    public final NLPMetricsIF.AVG_CIC AVG_CIC = (ASTNode,source) -> {
        OptionalDouble result = ASTNode.findAll(MethodDeclaration.class).stream().parallel() // extract all methods in sub-tree
                .filter(method -> method.getComment().isPresent()) // keep only methods that have comments
                .mapToDouble(method ->
                        computeCIC(nlpUtils.tokenize(method.getComment().get().getContent()) // tokenize comment to get terms
                                        .stream().collect(Collectors.toSet()), // convert to set
                                nlpUtils.tokenizeIdentifiers(
                                        astExtractor.extractIdentifiers(method).stream() // extract method-body identifiers
                                                .map(identifier -> identifier.getName())
                                                .collect(Collectors.toList())
                                ).stream().collect(Collectors.toSet()))) // collect to set
                .average(); // average of all methods
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    public final NLPMetricsIF.MAX_CIC MAX_CIC = (ASTNode,source) -> {
        OptionalDouble result = ASTNode.findAll(MethodDeclaration.class).stream().parallel() // extract all methods in sub-tree
                .filter(method -> method.getComment().isPresent()) // keep only methods that have comments
                .mapToDouble(method ->
                        computeCIC(nlpUtils.tokenize(method.getComment().get().getContent()) // tokenize comment to get terms
                                        .stream().collect(Collectors.toSet()), // convert to set
                                nlpUtils.tokenizeIdentifiers(
                                        astExtractor.extractIdentifiers(method).stream() // extract method-body identifiers
                                                .map(identifier -> identifier.getName())
                                                .collect(Collectors.toList())
                                ).stream().collect(Collectors.toSet()))) // collect to set
                .max(); // average of all methods
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Measures the textual-cohesion (TC) of all the control-statements found in the given
     * ast-subtree.  The cartesian product of the set of all control-statements in the sub-tree is used
     * to compute the TC of each pair of control-statements, and
     */
    public final NLPMetricsIF.TC_MIN TC_MIN = (ASTNode,source) ->
    {
        Set<Node> controlStatements =  astExtractor.stripControlStatements( // strip inner control-statements from control-statements (control-statements inside other control-statements) to avoid duplicate comparison
                astExtractor.extractControlStatements(ASTNode.clone())
        );

        OptionalDouble result=
                setUtils.allPairs(controlStatements).stream().parallel()
                        .filter(tuple -> ! tuple.getX().equals(tuple.getY())) // remove pairs where X == Y
                        // .forEach(p -> System.out.println("#########"+System.lineSeparator()+p.getX()+System.lineSeparator()+"------------"+System.lineSeparator()+p.getY()+System.lineSeparator()+System.lineSeparator()));
                        .mapToDouble(controlStmTuple -> computeTC(controlStmTuple.getX(),controlStmTuple.getY())) // compute TC over the tuple
                        .min();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Measures the average NMI (Narrow-meaning-identifiers) for all identifiers in a given AST-subtree
     */
    public final NLPMetricsIF.NMI_AVG AVG_NMI = (ASTNode,source) ->
    {
        OptionalDouble result = astExtractor.extractIdentifiers(ASTNode).stream().parallel()
                .flatMap(identifier -> nlpUtils.tokenizeIdentifier(identifier.getName()).stream())
                .map(token -> nlpUtils.normalize(token))
                .map(token -> WordNetAdapter.getWord(token)) // NOTE: POS-ANALYSIS SHOULD BE USED TO DETERMINE POS CATEGORY, ELSE FIND A WAY TO NOT HAVE TO SPECIFY POS CATEGORY... CURRENTLY ONLY WORKS WITH NOUNS SINCE NON-NOUNS WILL BE NULL, AND FILTERED OUT (NOT INCLUDED IN METRIC MEASURE)
                .filter(word -> word != null) // only keep non-null words
                .mapToDouble(word -> WordNetAdapter.getWordHypernymDepth(word))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Uses the java_fathom (source: https://github.com/ogrodnek/java_fathom) open-source
     * library to compute Flesch-Kincaid metric on each comment,
     * then returns the average
     */
    public final NLPMetricsIF.CR_AVG AVG_CR = (ASTNode,source) ->
    {
        OptionalDouble result = ASTNode.getAllContainedComments().stream().parallel()
                .mapToDouble(comment -> Readability.calcFlesch(Fathom.analyze(comment.getContent())))
                .filter(Double::isFinite)
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    };

    /**
     * Receives two control-block nodes as input, and computes the overlap of identifiers between them
     * @param a
     * @param b
     * @return
     */
    private double computeTC(Node a, Node b)
    {

        Set<String> termsFromA =
                nlpUtils.tokenizeIdentifiers(
                        astExtractor.extractIdentifiers(a).stream()
                                .map(identifier -> identifier.getName()).collect(Collectors.toList())).stream()
                        .map(term -> term.toLowerCase()).collect(Collectors.toSet());

        Set<String> termsFromB =
                nlpUtils.tokenizeIdentifiers(
                astExtractor.extractIdentifiers(b).stream()
                        .map(identifier -> identifier.getName()).collect(Collectors.toList())).stream()
                       .map(term -> term.toLowerCase()).collect(Collectors.toSet());

        return numUtils.safeDivide( // safe-divide to avoid division-by-zero exception
                setUtils.intersection(termsFromA,termsFromB).size(),  // get intersection cardinality
                setUtils.union(termsFromA, termsFromB).size()); // get union of the two
    }


    /**
     * Measures the overlap of tokens used in a given method comment and the identifiers used in method body.
     * @param Comment tokens
     * @param Body identifiers
     * @return metricsComputers result (fraction of overlap)
     */
    private double computeCIC(Set<String> commentTerms, Set<String> bodyIdentifiers) {
        return numUtils.safeDivide(
                setUtils.intersection(commentTerms, bodyIdentifiers).size(),  // get intersection cardinality
                setUtils.union(commentTerms, bodyIdentifiers).size()); // get union of the two
    }

    /**
     * Measures the fraction of identifiers that is present in a given dictionary
     * @param identifierTextNodes
     * @return metricsComputers result (fraction of overlap)
     */
    private double computeITID(Set<String> identifiers)
    {
        return  numUtils.safeDivide(
                identifiers.stream().parallel().filter(WordNetAdapter::isWord).count(),  // get intersection cardinality
                identifiers.size()); // divide by TextNodes cardinality
    }

    // GETTERS AND SETTERS:

    public Set<String> getDefaultDictionary() {
        return defaultDictionary;
    }

    public void setDefaultDictionary(Set<String> defaultDictionary) {
        this.defaultDictionary = defaultDictionary;
    }
}
