package metricsComputers;

import com.github.javaparser.ast.Node;
import interfaces.MetricsSnapshotIF;
import interfaces.ModelComputerIF;

public class ModelComputerOld implements ModelComputerIF {
    private StructuralMetrics structuralMetrics;
    private NLPMetrics nlpMetrics;

    public ModelComputerOld(
            StructuralMetrics structuralMetrics,
             NLPMetrics nlpMetrics)
    {
        this.structuralMetrics = structuralMetrics;
        this.nlpMetrics = nlpMetrics;
    }
    /**
     * Computes a total readability score from a metricsSnapshot instance.
     * @param source-code as string
     * @param ASTNode of class
     * @param structuralMetrics
     * @param nlpMetrics
     * @return total readability score (double)
     */
    public double computeTotalClassScore(MetricsSnapshotIF metricsSnapshot)
    {
        return
                        -0.9207 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC) +
                        -0.0638 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC) +
                        -0.0636 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC) +
                        -0.1469 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC) +
                        -0.1376 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER) +
                        -0.2413 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_PERIODS) +
                        -0.2134 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_COMMAS) +
                         0.831  * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_PARENTHESIS) +
                        -0.3088 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_COMPARISONS) +
                        -0.4769 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_ASSIGNMENTS) +
                         0.0085 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_LINE_LENGTH_FUNC) +
                        -0.003  * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_LINE_LENGTH_FUNC) +
                        -0.1452 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC) +
                         0.1765 * metricsSnapshot.getMetricsValues().get(structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC)+
                         0.0053 * metricsSnapshot.getMetricsValues().get(structuralMetrics.MAX_INSTANCES_OF_CHARS) +
                        -0.9672 * metricsSnapshot.getMetricsValues().get(nlpMetrics.TC_MAX) +
                        -2.7323 * metricsSnapshot.getMetricsValues().get(nlpMetrics.TC_MIN) +
                         3.5481 * metricsSnapshot.getMetricsValues().get(nlpMetrics.AVG_TC) +
                         0.1366 * metricsSnapshot.getMetricsValues().get(nlpMetrics.MIN_ITID) +
                         1.4448 * metricsSnapshot.getMetricsValues().get(nlpMetrics.MAX_CIC) +
                         5.471;
    }


    /**
     * Computes a total readability score for a given class.
     * @param source-code as string
     * @param ASTNode of class
     * @param structuralMetrics
     * @param nlpMetrics
     * @return total readability score (double)
     */
    public double computeTotalClassScore(String source,
                                         Node ASTNode)
    {
        return
                        -0.9207 * structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC.apply(ASTNode,source) +
                        -0.0638 * structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC.apply(ASTNode,source) +
                        -0.0636 * structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC.apply(ASTNode,source) +
                        -0.1469 * structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC.apply(ASTNode,source) +
                        -0.1376 * structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER.apply(ASTNode,source) +
                        -0.2413 * structuralMetrics.AVG_NUMBER_OF_PERIODS.apply(ASTNode,source) +
                        -0.2134 * structuralMetrics.AVG_NUMBER_OF_COMMAS.apply(ASTNode,source) +
                         0.831  * structuralMetrics.AVG_NUMBER_OF_PARENTHESIS.apply(ASTNode,source) +
                        -0.3088 * structuralMetrics.AVG_NUMBER_OF_COMPARISONS.apply(ASTNode,source) +
                        -0.4769 * structuralMetrics.AVG_NUMBER_OF_ASSIGNMENTS.apply(ASTNode,source) +
                         0.0085 * structuralMetrics.AVG_LINE_LENGTH_FUNC.apply(ASTNode,source) +
                        -0.003  * structuralMetrics.MAX_LINE_LENGTH_FUNC.apply(ASTNode,source) +
                        -0.1452 * structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC.apply(ASTNode,source) +
                         0.1765 * structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC.apply(ASTNode,source)+
                         0.0053 * structuralMetrics.MAX_INSTANCES_OF_CHARS.apply(ASTNode,source) +
                        -0.9672 * nlpMetrics.TC_MAX.apply(ASTNode,source) +
                        -2.7323 * nlpMetrics.TC_MIN.apply(ASTNode,source) +
                         3.5481 * nlpMetrics.AVG_TC.apply(ASTNode,source) +
                         0.1366 * nlpMetrics.MIN_ITID.apply(ASTNode,source) +
                         1.4448 * nlpMetrics.MAX_CIC.apply(ASTNode,source) +
                         5.471;
    }

}
