package exceptions;

/**
 * Exception for when attempting to select or fetch a tab that does not exist
 * in the gui
 */
public class NoSuchTabException extends RuntimeException {
    public NoSuchTabException(String message)
    {
        super(message);
    }
}
