package exceptions;

/**
 * Used when a mapping from a non-existing metrics function is attempted to be produced
 * (used by SuggestionFactory)
 */
public class NoSuchMetricException extends RuntimeException {
    public NoSuchMetricException(String str)
    {
        super(str);
    }
}
