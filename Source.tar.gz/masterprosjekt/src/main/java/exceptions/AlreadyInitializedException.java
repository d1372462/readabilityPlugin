package exceptions;

/**
 * Used when a class that can only be initialized once is initialized multiple times
 */
public class AlreadyInitializedException extends RuntimeException {

}
