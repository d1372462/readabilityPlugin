package exceptions;

/**
 * Exception thrown when attempting to obtain the weight of a function
 * for which there is no weight associated
 */
public class WeightNotFoundException extends RuntimeException {
    public WeightNotFoundException(String message)
    {
        super(message);
    }
}
