package constants;

/**
 * Contains file-path constants
 */
public abstract class FilePaths {
    public static final String WORDNET_DICTIONARY = "/home/user/GIT/masterprosjekt/libs/wordnet/dict";
}
