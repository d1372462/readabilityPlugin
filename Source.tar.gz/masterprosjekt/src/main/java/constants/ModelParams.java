package constants;

/**
 * Class holds constants for the internal readability model
 */
public abstract class ModelParams {
    public static final double READABILITY_CUTOFF = 3.6; // ref: http://www.cs.wm.edu/~denys/pubs/ICPC%2716-Readability.pdf
}
