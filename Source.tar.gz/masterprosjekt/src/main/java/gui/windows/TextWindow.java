package gui.windows;

import javax.swing.*;
import java.awt.*;

public class TextWindow extends JFrame {

    public TextWindow(String title, String text)
    {
        setTitle(title);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(500,400);
        setLayout(new BorderLayout());
        JTextArea textArea = new JTextArea(text);
        textArea.setEditable(false);
        add(textArea, BorderLayout.CENTER);
        setAlwaysOnTop(true);
        setVisible(true);
    }

}
