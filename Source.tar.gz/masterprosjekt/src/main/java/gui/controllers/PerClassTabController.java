package gui.controllers;

import com.intellij.psi.PsiClass;
import com.intellij.ui.components.JBScrollPane;
import com.intellij.ui.components.JBTabbedPane;
import exceptions.NoSuchTabException;
import gui.fragments.CodeFeatureComponent;
import gui.fragments.FeaturesListComponent;
import gui.fragments.MetricsTabPanel;
import gui.fragments.SuggestionListComponent;
import interfaces.*;
import models.setModels.Tuple;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

public class PerClassTabController extends GUIBaseController implements PerClassTabControllerIF {
    private ProjectMetricsComputerIF projectMetricsComputerIF;
    private Comparator<NamedMetricFunc> metricsTableSortComparator = Comparator.comparing(NamedMetricFunc::stringName);
    private MetricsAggregatorIF metricsAggregator;
    private FactoryIF<MetricsSnapshotIF,SuggestionListComponent> suggestionListComponentFactory;

    public PerClassTabController(
            ProjectMetricsComputerIF projectMetricsComputerIF,
            MetricsAggregatorIF metricsAggregator,
            FactoryIF<MetricsSnapshotIF,SuggestionListComponent> suggestionListComponentFactory)
    {
        this.projectMetricsComputerIF = projectMetricsComputerIF;
        this.metricsAggregator = metricsAggregator;
        this.suggestionListComponentFactory = suggestionListComponentFactory;
    }

    /**
     * Receives a MetricsSnapshot of measured metrics results,
     * and updates the metrics results table in the gui
     * (synchronized to avoid overlap execution)
     * @param metricsSnapshot
     */
    public void addClassTab(String tabName, MetricsSnapshotIF metricsSnapshot)
    {
        // gather metrics results:
        List<BiFunction> complexityMetrics = metricsAggregator.getComplexityMeasures().stream()
                .filter(func -> metricsSnapshot.getMetricsValues().containsKey(func))
                .map(func -> (BiFunction)func)
                .collect(Collectors.toList());

        List<BiFunction> identifierNamingMetrics = metricsAggregator.getIdentifierNamingMeasures().stream()
                .filter(func -> metricsSnapshot.getMetricsValues().containsKey(func))
                .map(func -> (BiFunction)func)
                .collect(Collectors.toList());

        List<BiFunction> cohesionMetrics = metricsAggregator.getCohesionMeasures().stream()
                .filter(func -> metricsSnapshot.getMetricsValues().containsKey(func))
                .map(func -> (BiFunction)func)
                .collect(Collectors.toList());

        List<BiFunction> formattingMetrics = metricsAggregator.getFormattingMeasures().stream()
                .filter(func -> metricsSnapshot.getMetricsValues().containsKey(func))
                .map(func -> (BiFunction)func)
                .collect(Collectors.toList());

        // create parent tab-pane to hold code features and metrics tab:
        JTabbedPane classTabsPane = new JBTabbedPane();
        // create panel for each tab:
        JPanel codeFeaturesTabPanel = new JPanel(new BorderLayout());
        JPanel suggestionsTabPanel = new JPanel(new BorderLayout());
        MetricsTabPanel metricsTabPanel = new MetricsTabPanel();
        // PRODUCE GUI CONTENT:
        suggestionsTabPanel.add(new JBScrollPane(suggestionListComponentFactory.produce(metricsSnapshot)));
        // create feature-list panel:
        final List<Tuple<CodeFeatureComponent,List<BiFunction>>> features = new LinkedList<>();
        CodeFeatureComponent complexity = new CodeFeatureComponent("Complexity"
                , Color.BLACK);
        CodeFeatureComponent cohesion = new CodeFeatureComponent("Cohesion"
                , Color.BLACK);
        CodeFeatureComponent identifierNaming = new CodeFeatureComponent("Identifier Naming"
                , Color.BLACK);
        CodeFeatureComponent formatting = new CodeFeatureComponent("Formatting"
                , Color.BLACK);
        // add measures results rows:

        // COMPLEXITY:
        complexityMetrics.stream()
                 // keep only metrics results that exist in snapshot
                .map(func -> (NamedMetricFunc) func) // map to named metric func
                .forEach(metric -> // results as row
        complexity.getMetricsTable().getTableModel().addRow(new Object[]{
                metric.stringName(),
                metricsSnapshot.getMetricsValues().get(metric)})
        );
        // IDENTIFIER NAMING:
        identifierNamingMetrics.stream()
                .map(func -> (NamedMetricFunc) func) // map to named metric func
                .forEach(metric -> // results as row
                        identifierNaming.getMetricsTable().getTableModel().addRow(new Object[]{
                                metric.stringName(),
                                metricsSnapshot.getMetricsValues().get(metric)}));
        // DOCUMENTATION:
        cohesionMetrics.stream()
                .map(func -> (NamedMetricFunc) func) // map to named metric func
                .forEach(metric -> // results as row
                        cohesion.getMetricsTable().getTableModel().addRow(new Object[]{
                                metric.stringName(),
                                metricsSnapshot.getMetricsValues().get(metric)}));
        // FORMATTING:
        formattingMetrics.stream()
                .map(func -> (NamedMetricFunc) func) // map to named metric func
                .forEach(metric -> // results as row
                        formatting.getMetricsTable().getTableModel().addRow(new Object[]{
                                metric.stringName(),
                                metricsSnapshot.getMetricsValues().get(metric)}));
        // add features
        features.add(new Tuple<>(complexity, complexityMetrics));
        features.add(new Tuple<>(cohesion, cohesionMetrics));
        features.add(new Tuple<>(identifierNaming, identifierNamingMetrics));
        features.add(new Tuple<>(formatting, formattingMetrics));

        System.out.println(">>>>"+new Tuple<>(complexity, complexityMetrics).getY().size()+" : "+new Tuple<>(complexity, complexityMetrics).getY().stream()
                .filter(metricFunc ->  metricsSnapshot.getWeightedMetricsValues().containsKey(metricFunc)).count());
        // order by weighted sum score:
        Collections.sort(features, (t1, t2) ->
                // sum weighted scores:
                new Double(t1.getY().stream()
                                .filter(metricFunc ->  metricsSnapshot.getWeightedMetricsValues().containsKey(metricFunc))
                                .mapToDouble(metricFunc -> metricsSnapshot.getWeightedMetricsValues().get(metricFunc))
                        .sum()).compareTo(
                        t2.getY().stream()
                                .filter(metricFunc ->  metricsSnapshot.getWeightedMetricsValues().containsKey(metricFunc))
                                // sum weighted scores:
                                .mapToDouble(metricFunc -> metricsSnapshot.getWeightedMetricsValues().get(metricFunc))
                                .sum()));
        FeaturesListComponent featureList = new FeaturesListComponent(features.stream().map(tuple -> tuple.getX())
                .collect(Collectors.toList()));
        codeFeaturesTabPanel.add(featureList);
        // proceed:
        List<Object[]> rows = metricsSnapshot.getMetricsValues().keySet().stream()
                .map(metricFunc -> (NamedMetricFunc) metricFunc) // ensure safe to cast to NamedMetricFunc (not casting in separate operation to preserve hashcode)
                .sorted(metricsTableSortComparator)
                .map(
                        metricFunc-> new Object[]{
                                metricFunc.stringName(), // column 1 (metric string name)
                                metricsSnapshot.getMetricsValues().get(metricFunc) // column 2 (metric measure result - double)
                        })
                .collect(Collectors.toList());
        // add the two tabs to parent tab-pane:
        classTabsPane.addTab("Code Features",codeFeaturesTabPanel);
        classTabsPane.addTab("Suggestions",suggestionsTabPanel);
        classTabsPane.addTab("Measures",metricsTabPanel);
        getMainToolWindow().getClassTabs().addTab(tabName,classTabsPane);
        rows.forEach(row -> metricsTabPanel.getTableModel().addRow(row)); // add rows to model
        metricsTabPanel.updateUI();
        getMainToolWindow().getClassTabs().updateUI();
    }

    /**
     * Updates class-tabs with
     * @param metricsSnapshot
     * @param metricsMap
     */
    public synchronized void updateClassTabs(final Map<PsiClass, MetricsSnapshotIF> metricsMap, MetricsAggregatorIF metricsAggregator)
    {
        System.out.println("######"+getMainToolWindow());
        getMainToolWindow().getClassTabs().removeAll(); // clear old tabs
        metricsMap.keySet().stream()
                .sorted(Comparator.comparing(PsiClass::getName))
                .forEach(psiClass ->
                        {
                           addClassTab(
                                   psiClass.getName(),
                                   metricsMap.get(psiClass)
                           );
                        }
                );
    }

    /**
     * Selects a class-tab (side-vertical) by tab-name
     * @param tabName
     */
    public synchronized void selectTab(String tabName)
    {
        int totalTabs = getMainToolWindow().getClassTabs().getTabCount();
        for(int i = 0; i < totalTabs; i++)
        {
            if (getMainToolWindow().getClassTabs().getTitleAt(i).equals(tabName)) // check if correct tab
            {
                getMainToolWindow().getClassTabs().setSelectedIndex(i); // select the given tab
                return; // done... return
            }
        }
        throw new NoSuchTabException("Tab not found: " + tabName);
    }

    // GUI METHODS (synchronized to ensure call-order is preserved and avoid concurrent-calls):

    /**
     * Aggregated method to update metrics tabs in gui
     * (facade method that calls other methods)
     * @param snapshotPerClass
     * @param metricsAggregator
     */
    public synchronized void updateMetricsTabsGUI(Map<PsiClass, MetricsSnapshotIF> snapshotPerClass)
    {
        updateClassTabs(snapshotPerClass,metricsAggregator);  // update gui:
        addClassTab("Project Average", projectMetricsComputerIF.avgAll(snapshotPerClass));
    }

    // SETTERS:

    public void setMetricsTableSortComparator(Comparator<NamedMetricFunc> metricsTableSortComparator) {
        this.metricsTableSortComparator = metricsTableSortComparator;
    }
}
