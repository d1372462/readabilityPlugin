package gui.controllers;

import exceptions.NoSuchTabException;
import interfaces.MainToolWindowControllerIF;

public class MainToolWindowController extends GUIBaseController implements MainToolWindowControllerIF {

    /**
     * Selects a tab (top horizontal) by tab-name
     * @param tabName
     */
    public synchronized void selectTab(String tabName)
    {
        int totalTabs = getMainToolWindow().getMainTabbedPane().getTabCount();
        for(int i = 0; i < totalTabs; i++)
        {
            if (getMainToolWindow().getMainTabbedPane().getTitleAt(i).equals(tabName)) // check if correct tab
            {
                getMainToolWindow().getMainTabbedPane().setSelectedIndex(i); // select the given tab
                return; // done... return
            }
        }
        throw new NoSuchTabException("Tab not found: " + tabName);
    }
}
