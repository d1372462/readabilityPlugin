package gui.controllers;

import app.CurrentState;
import gui.MainToolWindowFactory;

public class GUIBaseController {

    public MainToolWindowFactory getMainToolWindow()
    {
        return CurrentState.getInstance().getMainToolWindow(); // proxy-method for global main-tool-window (SHOULD BE DONE WITHOUT GLOBAL STATE!)
    }
}
