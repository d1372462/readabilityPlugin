package gui.controllers;

import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import gui.fragments.ClassComponent;
import gui.fragments.PackageListComponent;
import interfaces.*;

import java.awt.*;
import java.util.Map;

import static constants.ModelParams.READABILITY_CUTOFF;

public class ProjectOverviewController extends GUIBaseController implements ProjectOverviewControllerIF {
    private IDEAdapterIF IDEAdapter;
    private ActionListenerAssignerIF actionListenerAssigner;
    private MainToolWindowControllerIF mainToolWindowController;
    private PerClassTabControllerIF perClassTabController;

    public ProjectOverviewController(IDEAdapterIF IDEAdapter,
                                     ActionListenerAssignerIF actionListenerAssigner,
                                     MainToolWindowControllerIF mainToolWindowController,
                                     PerClassTabControllerIF perClassTabController) {
        this.IDEAdapter = IDEAdapter;
        this.actionListenerAssigner = actionListenerAssigner;
        this.mainToolWindowController = mainToolWindowController;
        this.perClassTabController = perClassTabController;
    }

    @Override
    public void updateProjectOverview(Project project, Map<PsiClass, Double> classScores)
    {
        clearProjectOverview();
      IDEAdapter.getPackagesInProject(project).stream().forEach(projPackage ->
                {
                    // make and add package component:
                        PackageListComponent pack =  new PackageListComponent(projPackage.getName());
                        for(PsiClass psiClass : projPackage.getClasses())
                        {
                            // make and add class component:
                            ClassComponent classComponent = new ClassComponent(
                                    psiClass.getName(),
                                    classScores.get(psiClass),
                                    classScores.get(psiClass) >= READABILITY_CUTOFF ? Color.GREEN : Color.RED // cutoff at 3.17 ... all classes lower than 3.17 is classified as "not readable"
                            );
                            actionListenerAssigner.assign(classComponent, mainToolWindowController, perClassTabController);
                            pack.getClassesPanel().add(classComponent);
                        }
                        getMainToolWindow()
                                .getProjectOverviewPanel()
                                .add(pack);
                }
        );
    }

    // INTERNAL METHODS:
    private void clearProjectOverview()
    {
        getMainToolWindow()
                .getProjectOverviewPanel()
                .removeAll();
    }
}
