package gui.controllers;

import app.CurrentState;
import com.intellij.openapi.project.Project;
import com.intellij.psi.PsiClass;
import gui.fragments.SuggestionListComponent;
import interfaces.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Main-GUI controller composed of several other controllers
 */
public class ComposedMainGUIController extends GUIBaseController {
    private ProjectMetricsComputerIF projectMetricsComputerIF;
    private IDEAdapterIF ideAdapter;
    private ModelComputerIF modelComputer;
    private PerClassTabControllerIF tabsController;
    private ProjectOverviewController projectOverviewController;

    public ComposedMainGUIController(
            IDEAdapterIF ideAdapter,
            ProjectMetricsComputerIF projectMetricsComputer,
            ModelComputerIF modelComputer,
            FactoryIF<MetricsSnapshotIF,SuggestionListComponent> suggestionListComponentFactory,
            PerClassTabControllerIF tabsController,
            ProjectOverviewController projectOverviewController)
    {
        this.ideAdapter = ideAdapter;
        this.projectMetricsComputerIF = projectMetricsComputer;
        this.modelComputer = modelComputer;
        this.tabsController=tabsController;
        this.projectOverviewController = projectOverviewController;
    }

    /**
     * Updates all stats in Main-gui using several other controllers
     * @param project to show/measure stats on
     */
    public void updateAllStats(Project project)
    {
        // compute metrics scores:
        Map<PsiClass, MetricsSnapshotIF> metricsResults = projectMetricsComputerIF.computeAllOnProject(project);
        // update metrics tabs:
        tabsController.updateMetricsTabsGUI(metricsResults); // update gui with new measures on project
        // select current class in metrics viewer:
        try{
            tabsController.selectTab(ideAdapter.getCurrentOpenFile(
                    CurrentState.getInstance().getCurrentProject()
            ).getNameWithoutExtension());
        } catch(Exception e)
        {
            e.printStackTrace();
        }
        Map<PsiClass, Double> classScores = new HashMap<>();
        metricsResults.keySet().stream().forEach(psiClass ->
        classScores.put(psiClass,
                modelComputer.computeTotalClassScore(
                        metricsResults.get(psiClass)
                )));

        // update project-overview:
        projectOverviewController.updateProjectOverview(project , classScores);
        }
}
