package gui.forms;

import javax.swing.*;
import java.awt.*;

public class ClassStatsWindow extends JFrame {
    public ClassStatsWindow()
    {
        this.setSize(500,500);
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        this.setVisible(true);

    }
}
