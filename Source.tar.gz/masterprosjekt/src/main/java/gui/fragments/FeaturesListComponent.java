package gui.fragments;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * GUI component consisting of a list of code-feature components
 */
public class FeaturesListComponent extends JPanel
{
    /**
     * Initializes the feature list component
     * @param featureComponents - list of code-feature GUI components to add
     */
    public FeaturesListComponent(List<CodeFeatureComponent> featureComponents)
    {
        this();
        updateFeatures(featureComponents);
    }

    public FeaturesListComponent()
    {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setBackground(Color.WHITE);
    }

    /**
     * Receives a list of code-feature components, and updates the ui
     * @param featureComponents
     */
    public void updateFeatures(List<CodeFeatureComponent> featureComponents)
    {
        this.removeAll();
        featureComponents.stream().forEach(
                feature -> {
                    this.add(feature); // add each feature from list
                    this.addPadding(); // add spacing between
                }
        );
        this.revalidate();
        this.repaint();
    }

    private void addPadding()
    {
        this.add( Box.createRigidArea(new Dimension(1,20)));
    }
}
