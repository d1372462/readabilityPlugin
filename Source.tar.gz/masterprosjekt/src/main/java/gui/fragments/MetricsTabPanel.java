package gui.fragments;

import com.intellij.ui.components.JBScrollPane;
import com.intellij.ui.table.JBTable;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/**
 * Represents a given metrics-tab pane
 */
public class MetricsTabPanel extends DefaultTabPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    public MetricsTabPanel()
    {
        tableModel = new DefaultTableModel(new Object[0][0], new String[]{"Measure","Value"});
        table = new JBTable(tableModel);
        this.add(new JBScrollPane(table),BorderLayout.CENTER);
    }

    // GETTERS:

    public JTable getTable() {
        return table;
    }

    public DefaultTableModel getTableModel() {
        return tableModel;
    }

    // SETTERS:

    public void setTable(JTable table) {
        this.table = table;
    }

    public void setTableModel(DefaultTableModel tableModel) {
        this.tableModel = tableModel;
    }
}
