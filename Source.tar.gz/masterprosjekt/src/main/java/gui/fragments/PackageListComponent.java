package gui.fragments;

import javax.swing.*;
import java.awt.*;

public class PackageListComponent extends JPanel {
private JPanel classesPanel;
    public PackageListComponent(String packageName)
    {
        setLayout(new BorderLayout());
        classesPanel = new JPanel();
        classesPanel.setLayout(new BoxLayout(classesPanel, BoxLayout.Y_AXIS));
        JLabel packageLabel = new JLabel(packageName);
        packageLabel.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 16));
        this.add(packageLabel, BorderLayout.NORTH);
        this.add(new JScrollPane(classesPanel), BorderLayout.CENTER);
    }

    public JPanel getClassesPanel() {
        return classesPanel;
    }

    public void setClassesPanel(JPanel classesPanel) {
        this.classesPanel = classesPanel;
    }
}
