package gui.fragments.generic;

import javax.swing.table.DefaultTableModel;
import java.util.List;

public class CustomTableModel extends DefaultTableModel {
        public CustomTableModel(List<String> columns, List<String[]> values) {
            super(values.toArray(new Object[][] {}),columns.toArray());
        }

        @Override
        public boolean isCellEditable(int row, int col) {
            return false;
        }

}
