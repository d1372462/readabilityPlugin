package gui.fragments.generic;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DefaultTable extends JTable{
    // declare private references:
    private DefaultTableModel tableModel;
    public DefaultTableModel getDefaultTableModel(){
        return tableModel;
    }

    public DefaultTable(List<String> columns, List<String[]> values){
        tableModel = new CustomTableModel(columns,values);
        this.setModel(tableModel);
        this.setBackground(Color.decode("#FFFFFF"));
        this.setFont(new Font("Arial", Font.BOLD, 13));
        this.setRowHeight(32);
        this.getTableHeader().setFont(new Font("Consolas", Font.BOLD, 17));
        this.getTableHeader().setBackground(Color.decode("#0080FF"));
        this.getTableHeader().setForeground(Color.WHITE);
    }


    public int getRowCount(){
        return tableModel.getRowCount();
    }

    public  void removeRow(int row){
        if(getRowCount() > row){
            tableModel.removeRow(row);
        }
    }

    public DefaultTableModel getTableModel() {
        return tableModel;
    }

    public void setTableModel(DefaultTableModel tableModel) {
        this.tableModel = tableModel;
    }
}