package gui.fragments;

import com.intellij.ui.components.JBLabel;
import com.intellij.ui.components.JBScrollPane;
import gui.fragments.generic.DefaultTable;
import gui.fragments.generic.RoundedBorder;
import interfaces.SuggestionComponentIF;
import interfaces.SuggestionIF;
import models.Suggestion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;

/**
 * A code-feature component to be used in the ClassStatsWindow
 */
public class SuggestionComponent extends JPanel implements SuggestionComponentIF {
    private Font defaultFont;
    private JPanel midPanel;
    private SuggestionIF suggestion;
    private JBLabel suggestionLabel;
    private JBLabel rankLabel;

    public SuggestionComponent(SuggestionIF suggestion, Color bgColor)
    {
        this(bgColor); // call overloaded constructor
        this.suggestion = suggestion;
        this.suggestionLabel.setText(suggestion.getTitle());

    }

    public SuggestionComponent(Color bgColor)
    {
        defaultFont = new Font("", Font.BOLD, 14);
        setLayout(new BorderLayout());
        suggestionLabel = new JBLabel();
        rankLabel = new JBLabel();
        suggestionLabel.setForeground(Color.WHITE);
        rankLabel.setForeground(Color.WHITE);
        rankLabel.setMaximumSize(new Dimension(100,50));
        suggestionLabel.setFont(defaultFont);
        rankLabel.setFont(defaultFont);
        JPanel outerPanel = new JPanel(new BorderLayout());
        // add padding to outer panel:
        outerPanel.add(Box.createRigidArea(new Dimension(1,8)),BorderLayout.NORTH); // top-padding
        outerPanel.add(Box.createRigidArea(new Dimension(15,1)),BorderLayout.EAST); // right-padding
        outerPanel.add(Box.createRigidArea(new Dimension(15,1)),BorderLayout.WEST); // left-padding
        outerPanel.setBackground(Color.WHITE);
        JPanel outerMid = new JPanel();
        outerMid.setLayout(new BorderLayout());
        outerMid.setBackground(Color.WHITE);
        midPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JPanel innerMidPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        innerMidPanel.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
        innerMidPanel.setBackground(bgColor);
        innerMidPanel.setMaximumSize(new Dimension(1000,1000));
        innerMidPanel.add(rankLabel);
        // add some padding:
        innerMidPanel.add(Box.createRigidArea(new Dimension(15,1)));
        innerMidPanel.add(suggestionLabel);
        innerMidPanel.add(Box.createRigidArea(new Dimension(30,1)));
        midPanel.add(innerMidPanel);
        midPanel.setBackground(bgColor);
        midPanel.setBorder(new RoundedBorder(2));
        outerMid.add(midPanel,BorderLayout.NORTH);
        outerPanel.add(outerMid,BorderLayout.CENTER);
        add(outerPanel,BorderLayout.CENTER);
        updateUI();
        midPanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }


   // SETTERS AND GETTERS:

    public JLabel getSuggestionLabel() {
        return suggestionLabel;
    }

    public void setSuggestionLabel(JBLabel suggestionLabel) {
        this.suggestionLabel = suggestionLabel;
    }

    public Font getDefaultFont() {
        return defaultFont;
    }

    public void setDefaultFont(Font defaultFont) {
        this.defaultFont = defaultFont;
    }

    public JPanel getMidPanel() {
        return midPanel;
    }

    public void setMidPanel(JPanel midPanel) {
        this.midPanel = midPanel;
    }

    public SuggestionIF getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(SuggestionIF suggestion) {
        this.suggestion = suggestion;
    }

    public JBLabel getRankLabel() {
        return rankLabel;
    }

    public void setRankLabel(JBLabel rankLabel) {
        this.rankLabel = rankLabel;
    }
}
