package gui.fragments;

import gui.fragments.generic.DefaultTable;
import gui.fragments.generic.RoundedBorder;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.LinkedList;
import java.util.List;

/**
 * A code-feature component to be used in the ClassStatsWindow
 */
public class CodeFeatureComponent extends JPanel {
    private JLabel featureLabel;
    private Font defaultFont;
    private DefaultTable metricsTable; // metrics measures table for class
    private JScrollPane metricsTableScrollPane;
    public CodeFeatureComponent(String featureLabel, Color bgColor)
    {
        this(bgColor); // call overloaded constructor
        this.featureLabel.setText(featureLabel);
    }

    public CodeFeatureComponent(Color bgColor)
    {
        // set metrics-table headers:
        List<String> cols = new LinkedList<>();
        cols.add("Metric");
        cols.add("Measure");
        metricsTable = new DefaultTable(cols, new LinkedList<>());
        metricsTableScrollPane = new JScrollPane(metricsTable);
        metricsTableScrollPane.setVisible(false);
        this.defaultFont = new Font("", Font.BOLD, 20);
        this.setLayout(new BorderLayout());
        this.featureLabel = new JLabel();
        featureLabel.setForeground(Color.WHITE);
        this.featureLabel.setFont(defaultFont);
        JPanel outerPanel = new JPanel(new BorderLayout());
        // add padding to outer panel:
        outerPanel.add(Box.createRigidArea(new Dimension(1,10)),BorderLayout.NORTH); // top-padding
        outerPanel.add(Box.createRigidArea(new Dimension(15,1)),BorderLayout.EAST); // right-padding
        outerPanel.add(Box.createRigidArea(new Dimension(15,1)),BorderLayout.WEST); // left-padding
        outerPanel.setBackground(Color.WHITE);

        JPanel outerMid = new JPanel();
        outerMid.setLayout(new BorderLayout());
        outerMid.setBackground(Color.WHITE);
        JPanel midPanel = new JPanel(new GridBagLayout());
        JPanel innerMidPanel = new JPanel(new FlowLayout());
        innerMidPanel.setBackground(bgColor);

        innerMidPanel.setMaximumSize(new Dimension(1000,1000));
        innerMidPanel.add(featureLabel);
        innerMidPanel.add(Box.createRigidArea(new Dimension(30,1)));
        midPanel.add(innerMidPanel);
        midPanel.setBackground(bgColor);
        midPanel.setBorder(new RoundedBorder(2));
        outerMid.add(midPanel,BorderLayout.NORTH);
        outerMid.add(metricsTableScrollPane,BorderLayout.CENTER);
        outerPanel.add(outerMid,BorderLayout.CENTER);
        this.add(outerPanel,BorderLayout.CENTER);
        this.updateUI();
        midPanel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        midPanel.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
                // show or hide metrics table:
                if(metricsTableScrollPane.isVisible())
                {
                    metricsTableScrollPane.setVisible(false);
                }else{
                    metricsTableScrollPane.setVisible(true);
                }
                // fire component updates:
                midPanel.updateUI();
                outerMid.updateUI();
                outerPanel.updateUI();
                innerMidPanel.updateUI();
            }

            @Override
            public void mousePressed(MouseEvent mouseEvent) {

            }

            @Override
            public void mouseReleased(MouseEvent mouseEvent) {

            }

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {

            }

            @Override
            public void mouseExited(MouseEvent mouseEvent) {

            }
        });
    }


    public DefaultTable getMetricsTable() {
        return metricsTable;
    }

    public void setMetricsTable(DefaultTable metricsTable) {
        this.metricsTable = metricsTable;
    }
}
