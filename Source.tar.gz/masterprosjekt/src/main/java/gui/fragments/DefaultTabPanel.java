package gui.fragments;

import javax.swing.*;
import java.awt.*;

public class DefaultTabPanel extends JPanel {

    public DefaultTabPanel()
    {
        this.setLayout(new BorderLayout());
    }
}
