package gui.fragments;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 * GUI component consisting of a list of code-feature components
 */
public class SuggestionListComponent extends JPanel
{
    /**
     * Initializes the feature list component
     * @param featureComponents - list of code-feature GUI components to add
     */
    public SuggestionListComponent(List<SuggestionComponent> suggestionComponents)
    {
        this();
        updateSuggestions(suggestionComponents);
    }

    public SuggestionListComponent()
    {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setBackground(Color.WHITE);
    }

    /**
     * Receives a list of code-feature components, and updates the ui
     * @param featureComponents
     */
    public void updateSuggestions(List<SuggestionComponent> suggestionComponents)
    {
        this.removeAll();
        suggestionComponents.stream().forEach(
                suggestion -> {
                    this.add(suggestion); // add each feature from list
                    this.addPadding(); // add spacing between
                }
        );
        this.revalidate();
        this.repaint();
    }

    private void addPadding()
    {
        this.add( Box.createRigidArea(new Dimension(1,20)));
    }
}
