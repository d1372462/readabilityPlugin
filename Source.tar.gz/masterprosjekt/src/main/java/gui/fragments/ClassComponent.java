package gui.fragments;

import interfaces.ClassComponentIF;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;

public class ClassComponent extends JPanel implements ClassComponentIF {

    private  JButton classLabelButton;
    private JLabel scoreLabel;
    private String className;

    public ClassComponent(String className, double score, Color color)
    {
        this.className = className;
        DecimalFormat df = new DecimalFormat("#.##");
        this.setLayout(new BorderLayout());
        JPanel scorePanel = new JPanel();
        scorePanel.setLayout(new BoxLayout(scorePanel, BoxLayout.X_AXIS));
        scorePanel.setPreferredSize(new Dimension(100,25));
        scorePanel.setBackground(color);
        setBackground(color);
        scoreLabel = new JLabel(df.format(score));
        scoreLabel.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 20));
        scorePanel.add(Box.createRigidArea(new Dimension(15,1)));
        scorePanel.add(scoreLabel);
        classLabelButton = new JButton(className);
        classLabelButton.setFont(new Font(Font.SANS_SERIF,  Font.BOLD, 14));
        classLabelButton.setForeground(Color.BLUE);
        classLabelButton.setBackground(color);
        this.add(classLabelButton, BorderLayout.CENTER);
        this.add(scorePanel, BorderLayout.EAST);
        this.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
    }

    public JButton getClassLabelButton() {
        return classLabelButton;
    }

    public void setClassLabelButton(JButton classLabelButton) {
        this.classLabelButton = classLabelButton;
    }

    public JLabel getScoreLabel() {
        return scoreLabel;
    }

    public void setScoreLabel(JLabel scoreLabel) {
        this.scoreLabel = scoreLabel;
    }

    public String getClassName() {
        return className;
    }
}
