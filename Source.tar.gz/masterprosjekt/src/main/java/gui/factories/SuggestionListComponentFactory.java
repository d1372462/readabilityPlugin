package gui.factories;

import factories.SuggestionFactory;
import gui.fragments.SuggestionComponent;
import gui.fragments.SuggestionListComponent;
import interfaces.*;
import metricsComputers.NLPMetrics;
import metricsComputers.StructuralMetrics;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

public class SuggestionListComponentFactory implements FactoryIF<MetricsSnapshotIF, SuggestionListComponent> {
    private StructuralMetrics structuralMetrics;
    private NLPMetrics nlpMetrics;
    private FactoryIF<BiFunction, SuggestionIF> suggestionFactory;
    private FactoryIF<SuggestionIF, SuggestionComponent> suggestionComponentFacotry;
    private ActionListenerAssignerIF actionListenerAssigner;

    public SuggestionListComponentFactory(
            StructuralMetrics structuralMetrics,
            NLPMetrics nlpMetrics,
            FactoryIF<BiFunction, SuggestionIF> suggestionFactory,
            FactoryIF<SuggestionIF, SuggestionComponent> suggestionComponentFacotry,
            ActionListenerAssignerIF actionListenerAssigner)
    {
        this.structuralMetrics = structuralMetrics;
        this.nlpMetrics = nlpMetrics;
        this.suggestionFactory = suggestionFactory;
        this.suggestionComponentFacotry = suggestionComponentFacotry;
        this.actionListenerAssigner = actionListenerAssigner;
    }

    @Override
    public SuggestionListComponent produce(MetricsSnapshotIF metricsMap) {
        // init facotories:
        FactoryIF<BiFunction, SuggestionIF> suggestionFactory = new SuggestionFactory(structuralMetrics, nlpMetrics);
        FactoryIF<SuggestionIF, SuggestionComponent> suggestionComponentFacotry = new SuggestionComponentsFactory();
        LinkedList<BiFunction> measures = new LinkedList<>(metricsMap.getWeightedMetricsValues().keySet());
        // sort by severity:
        Collections.sort(measures, new Comparator<BiFunction>(){
            public int compare(BiFunction s1, BiFunction s2) {
                return metricsMap.getWeightedMetricsValues().get(s1).compareTo(
                        metricsMap.getWeightedMetricsValues().get(s2)
                );
            }
        });
        List<SuggestionComponent> suggestionComponents = measures.stream()
                .map(suggestionFactory::produce) // map each meausre to a suggestion-obj
                .filter(suggestion -> suggestion != null) // remove null values
                .map(suggestionComponentFacotry::produce) // map suggestion-obj to suggestion-component(gui)
                .collect(Collectors.toList());
        // rank suggestion-components:
        int rank=0;
        for(SuggestionComponent suggestionComponent : suggestionComponents)
        {
            suggestionComponent.getRankLabel().setText("#"+ (rank++));
        }
        suggestionComponents.stream().forEach(actionListenerAssigner::assign); // assign action-listeners
        return new SuggestionListComponent(suggestionComponents);
    }
}
