package gui.factories;

import gui.fragments.SuggestionComponent;
import interfaces.SuggestionComponentsFactoryIF;
import interfaces.SuggestionIF;
import java.awt.*;

public class SuggestionComponentsFactory implements SuggestionComponentsFactoryIF {

    @Override
    public SuggestionComponent produce(SuggestionIF suggestion)
    {
                    SuggestionComponent suggestionComponent = new SuggestionComponent(suggestion, Color.BLACK);
                    return suggestionComponent;
    }
}
