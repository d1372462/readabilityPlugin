package gui;

import com.intellij.psi.PsiClass;
import gui.controllers.MainToolWindowController;
import gui.controllers.PerClassTabController;
import gui.forms.ClassStatsWindow;
import gui.fragments.ClassComponent;
import gui.fragments.SuggestionComponent;
import gui.windows.TextWindow;
import interfaces.*;
import models.setModels.MetricsSnapshot;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

/**
 * Class responsible for assigning action-listeners to given gui frames
 * (assign method is overloaded several times to provide functionality to assign listeners to different frame instances)
 */
public class ActionListenerAssigner implements ActionListenerAssignerIF {
    private Actions actions;
    public ActionListenerAssigner()
    {
        actions = new Actions();
    }

    /**
     * Assigns action-listeners to a MainToolWindowFactory instance
     * @param guiComponent
     */
    @Override
    public void assign(MainToolWindowFactory guiComponent)
    {
     //   guiComponent.getTestButton().addActionListener(actions.TEST_BUTTON_CLICK);
    }

    /**
     * Assigns action-listener to class gui component.
     * @param class-gui-component to assign to
     * @param psiClass the gui component represents
     * @param metricsSnapshot for the given class
     * @param metricsWeighter to use for weighting
     */
    @Override
    public void assign(ClassComponentIF component, PsiClass psiClass)
    {
        component.getClassLabelButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Class-label button clicked for class: "+psiClass.getName());
            }
        });

    }

    @Override
    public void assign(SuggestionComponent component)
    {
        component.getMidPanel().addMouseListener(new MouseListener() {
        @Override
        public void mouseClicked(MouseEvent mouseEvent) {
            // handle suggestion click here!
            JOptionPane.showMessageDialog(null,
                    component.getSuggestion().getDescription(),
                    component.getSuggestion().getTitle(),
                    JOptionPane.INFORMATION_MESSAGE);

        }

        @Override
        public void mousePressed(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseReleased(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseEntered(MouseEvent mouseEvent) {

        }

        @Override
        public void mouseExited(MouseEvent mouseEvent) {

        }
    });
    }

    @Override
    public void assign(ClassComponent classComponent,
                       MainToolWindowControllerIF mainToolWindowController,
                       PerClassTabControllerIF perClassTabController)
    {
        classComponent.getClassLabelButton().addActionListener(actionEvent -> {
            mainToolWindowController.selectTab("Per Class Overview"); // switch top-tab
            perClassTabController.selectTab(classComponent.getClassName());
        });
    }

}
