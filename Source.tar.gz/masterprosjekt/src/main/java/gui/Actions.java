package gui;

import com.intellij.openapi.command.WriteCommandAction;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.editor.markup.HighlighterLayer;
import com.intellij.openapi.editor.markup.HighlighterTargetArea;
import com.intellij.openapi.editor.markup.TextAttributes;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.project.ProjectManager;

import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Holds action-listeners that will be assigned to different gui-components by the ActionListenerAssigner
 */
public class Actions {
    /**
     * Action-function for MainToolWindow->testButton
     */
    public final ActionListener TEST_BUTTON_CLICK = e ->{
        // determine current open project (0 selected as dummy (does not work if multiple are open)
        Project currentProj = ProjectManager.getInstance().getOpenProjects()[0];
        // fetch file editor manager for current project:
        FileEditorManager fileEditorManager = FileEditorManager.getInstance(currentProj);
        // check editor open:
        if (
                fileEditorManager.getSelectedTextEditor() != null
                        && fileEditorManager.getSelectedTextEditor().getDocument() != null
                ) {
            Document currentDoc = fileEditorManager.getSelectedTextEditor().getDocument();
            String str = currentDoc.getText();

            //Making the replacement
            if (str.contains("class"))
            {
                int start = str.indexOf("class");
                int end = start + "class".length();
                // highlight code:
                final TextAttributes TEXT_ATTR = new TextAttributes(null, Color.yellow, null, null, Font.PLAIN);
                // add line highlighting:
                fileEditorManager.getSelectedTextEditor().getMarkupModel().addRangeHighlighter(start, end, HighlighterLayer.ERROR, TEXT_ATTR, HighlighterTargetArea.LINES_IN_RANGE);
                // example of replace code:
                WriteCommandAction.runWriteCommandAction(currentProj, () ->
                        currentDoc.replaceString(start, end, "interface")
                );
            } else {
                System.err.println("Class not found...");
            }

        } else {
            System.err.println("No document open currently...");
        }
    };
}
