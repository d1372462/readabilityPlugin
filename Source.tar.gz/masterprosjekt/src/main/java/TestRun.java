import com.github.javaparser.ast.CompilationUnit;
import helperUtils.FileUtils;
import interfaces.MetricsAggregatorIF;
import interfaces.NamedMetricFunc;
import metricsComputers.*;
import parsing.ASTBuilder;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Test class for manually testing using a main method
 * */
public class TestRun {

    public static void main2(String[] args)
    {
        StructuralMetrics structuralMetrics = new StructuralMetrics();
        NLPMetrics nlpMetrics = new NLPMetrics();
        MetricsAggregatorIF aggregator = new MetricsAggregator(structuralMetrics,nlpMetrics);

        String s = "class M{\n" +
                "public void buildModel() {\n" +
                " if(getTarget() != null){\n" +
                "\tObject target = getTarget();\n" +
                "\tObject kind = Model.getFacade().getAggregation(target);\n" +
                "\tif(kind == null || kind.equals(Model.getAggregatedKind().getNone())){\n" +
                "\t\tsetSelected(ActionSetAssociationEndAggregation.NONE_COMMAND);\n" +
                "\t}else{\n" +
                "\t\tsetSelected(ActionSetAssociationEndAggregation.AGGREGATE_COMMAND);\n" +
                "\t}\n" +
                "}\n" +
                "}\n" +
                "}";

        final CompilationUnit c = new ASTBuilder().buildAST(s);

    }
    public static void main(String[] args)
    {
        StructuralMetrics structuralMetrics = new StructuralMetrics();
        NLPMetrics nlpMetrics = new NLPMetrics();
        System.out.print("Snippet NR,");
        ModelComputer modelComputer = new ModelComputer(structuralMetrics,nlpMetrics);
        MetricsAggregatorIF metricsAggregator = new MetricsAggregator(structuralMetrics,nlpMetrics);

        metricsAggregator.getAll().stream().forEach(s -> System.out.print(((NamedMetricFunc)s).stringName()+","));

        try {
            Files.walk(Paths.get("/home/user/TEMP/Scalabrino/Snippets/"))
                    .filter(Files::isRegularFile)
                    .parallel()
                    .forEach(file ->
                            {
                                try {

                                   final String source = "class T{" +
                                            new FileUtils().readFileToString(new File(file.toString()))
                                            +"}";
                                    System.out.println("");

                                   System.out.print(file.getFileName()+",");
                                    final CompilationUnit c = new ASTBuilder().buildAST(source);
                                   metricsAggregator.getAll().stream().forEach(s -> System.out.print(s.apply(c,source)+","));
                                   } catch (Exception e) {
                                    System.out.println("Err with file: "+file.getFileName());
                                    e.printStackTrace();
                                }
                            }
                    );
        } catch (IOException e) {
            e.printStackTrace();
        }

        }




    public static void main9(String[] args)
    {
        StructuralMetrics structuralMetrics = new StructuralMetrics();
        NLPMetrics nlpMetrics = new NLPMetrics();
        System.out.print("Snippet NR, Score");
        ModelComputer modelComputer = new ModelComputer(structuralMetrics,nlpMetrics);
        MetricsAggregatorIF metricsAggregator = new MetricsAggregator(structuralMetrics,nlpMetrics);

System.out.println("");
        try {
            Files.walk(Paths.get("/home/user/TEMP/Scalabrino/Snippets/"))
                    .filter(Files::isRegularFile)
                    .parallel()
                    .forEach(file ->
                            {
                                try {

                                    final String source = "class T{" +
                                            new FileUtils().readFileToString(new File(file.toString()))
                                            +"}";
                                    final CompilationUnit c = new ASTBuilder().buildAST(source);
                                   System.out.println(file.getFileName()+","+ modelComputer.computeTotalClassScore(source,c));
                                } catch (Exception e) {
                                    System.out.println("Err with file: "+file.getFileName());
                                    e.printStackTrace();
                                }
                            }
                    );
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /*
    public static void main(String[] args) throws IOException {
        StructuralMetrics structuralMetrics = new StructuralMetrics();
        NLPMetrics nlpMetrics = new NLPMetrics();

        String filePath = "/home/user/TEMP/Scalabrino/Snippets/3.jsnp";
        String source = "class T{" +
                new FileUtils().readFileToString(new File(filePath))
                +"}";



      //  final String source ="class TestClass {int x; int y; int zz(int a){return a;} }";
        final CompilationUnit c = new ASTBuilder().buildAST(source);

   //    Node n = c.findAll(MethodDeclaration.class).stream().filter(m -> m.getNameAsString().equals("testFetchResponse")).findFirst().get();

       System.out.println(c);
        System.out.println("##: "+new ASTUtils().ASTNodeLineCount(c));
        System.out.println("Structural Metrics:");

        MetricsAggregator aggregator = new MetricsAggregator(structuralMetrics,nlpMetrics);
        System.out.println("---- METRICS RESULTS FOR "+filePath+" ----");
        Stack<Tuple<String,Double>> results = new Stack<>();
        // measure all metrics:
        aggregator.getAll().stream()
                .map(metricFunc -> new Tuple<>(
                        ((NamedMetricFunc)metricFunc).stringName(),
                        metricFunc.apply(c, source)))
                .forEach(results::push);

     // order by numeric result:
     Collections.sort(results, Comparator.comparing(Tuple::getX));
     // print results:
     while(! results.isEmpty())
     {
         Tuple t = results.remove(0);
         System.out.println(t.getX() + " : "+t.getY());
     }


    }
    */
}
