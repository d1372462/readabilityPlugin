package helperUtils;

import com.github.javaparser.ast.Node;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.*;
import java.util.stream.Collectors;

public class StrUtils {
    /**
     * Counts occurances of substring in given string
     * @param str
     * @param substr
     * @return int count of instances
     */
    public int countInstancesOfSubstr(String str, String substr)
    {
        return StringUtils.countMatches(str, substr);
    }

    /**
     * Counts occurances of any of the given substrings in given string
     * (Warning: Inefficient)
     * @param str
     * @param substr
     * @return int count of instances
     */
    public int countInstancesOfSubstr(String str, String[] substrs)
    {
        return Arrays.asList(substrs).stream()
                .mapToInt(substr -> countInstancesOfSubstr(str,substr))
                .sum();
    }

    /**
     * Counts occurances of any character  in given character array
     * @param str
     * @param substr
     * @return int count of instances
     */
    public TreeMap<Character,Integer> countInstancesOfCharacters(String str)
    {
        List<Character> chars = str.chars().mapToObj(e->(char)e).collect(Collectors.toList());
        TreeMap<Character,Integer> charCounts = new TreeMap<>();
        for(Character charcater : chars)
        {
            if (charCounts.get(charcater)==null)
            {
                charCounts.put(charcater,0);
            }
            charCounts.put(charcater,charCounts.get(charcater)+1);
        }
        return charCounts;
    }

    /**
     * Converts a given string to list of string lines
     * @param ASTNode
     * @return List of string lines
     */
    public List<String> stringToLines(String str)
    {
        return new BufferedReader(new StringReader(str))
                .lines().collect(Collectors.toList());
    }

    /**
     * Removes reserved keywords from string
     * (WARNING: Not reliable...)
     * @param str
     * @return
     */
    public String stripReservedKeywords(String str)
    {
        String[] reservedWords = new String[]{" abstract " , " assert " , " boolean " , " break " , " byte " , " case " ,
                " catch " , " char " , " class " , " const " , " continue " , " default " ,
                " double " , " do " , " else " , " enum " , " extends " , " false " ,
                " final " , " finally " , " float " , " for " , " goto " , " if " ,
                " implements " , " import " , " instanceof " , " int " , " interface " , " long " ,
                " native " , " new " , " null " , " package " , " private " , " protected " ,
                " public " , " return " , " short " , " static " , " strictfp " , " super " ,
                " switch " , " synchronized " , " this " , " throw " , " throws " , " transient" ,
                " true " , " try " , " void " , " volatile " , "  while(" };
        for(String keyw : reservedWords)
        {
            str = str.replace(keyw, "");
        }
        return str;
    }

    /**
     * Counts number of lines in string
     * @param String to measure
     * @return number of lines in string
     */
    public int lineCount(String str)
    {
        return stringToLines(str).size();
    }

}
