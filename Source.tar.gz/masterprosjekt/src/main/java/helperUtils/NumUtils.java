package helperUtils;

/**
 * Provides helper-methods for numeric operations
 */
public class NumUtils {
    /**
     * Performs a safe division of two doubles.
     * If either is zero, it will return zero.
     * @param num1
     * @param num2
     * @return
     */
    public double safeDivide(double num1, double num2)
    {
        if (num1 == 0.0 || num2==0.0)
        {
            return 0;
        }
        return num1 / num2;
    }


}
