package helperUtils;

import interfaces.FileUtilsIF;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtils implements FileUtilsIF{
    public String readFileToString(File file) throws IOException {
        // check file exists:
        if (! file.exists())
        {
            throw new FileNotFoundException("File not found");
        }
        return new String(Files.readAllBytes(Paths.get(file.getAbsolutePath())));
    }
}
