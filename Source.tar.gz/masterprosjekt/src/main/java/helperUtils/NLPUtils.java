package helperUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class NLPUtils {
    /**
     * Receives a given natural-language string as input, and returns a list of
     * tokens (tokenizes the string)
     * @param String to tokenize
     * @return List of tokens
     */
    public List<String> tokenize(String str)
    {
        return Arrays.stream(str.split(" "))
                .map(token -> token.trim().toLowerCase())
                .filter(token -> token.length()>0)
                .collect(Collectors.toList()); // temporary tokenization - TO BE REPLACED BY PROPER NLP TOKENIZATION
    }

    /**
     * Tokenizes a given identifyer, splitting it into it's given terms by camel-case
     * @param identifyer
     * @return List of terms from identifier
     */
    public List<String> tokenizeIdentifier(String identifyer)
    {
        return Arrays.stream(identifyer.split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])|_")).map(tok -> tok.trim().toLowerCase()).collect(Collectors.toList()); // split by camel-case
    }

    /**
     * Tokenizes a list of identifiers and returns a list of all terms from all
     * identifiers
     * @param identifiers
     * @return
     */
    public List<String> tokenizeIdentifiers(List<String> identifiers)
    {
        return identifiers.stream()
                .flatMap(identifier -> tokenizeIdentifier(identifier).stream())
                .collect(Collectors.toList());
    }

    /**
     * Receives a list of strings, and normalizes the strings by converting them to lower-case
     * @param list of strings in any case
     * @return list of lower-case strings
     */
    public List<String> normalize(List<String> strings)
    {
       return strings.stream()
               .map(this::normalize)
               .collect(Collectors.toList());
    }

    public String normalize(String str)
    {
        return str.toLowerCase();
    }

}
