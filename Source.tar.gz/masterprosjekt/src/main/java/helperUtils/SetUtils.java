package helperUtils;

import models.setModels.Tuple;

import java.util.*;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SetUtils {
    /**
     * Returns the intersection of two sets
     * @param set 1
     * @param set 2
     * @return Intersection of set 1 and 2 (set1 ^ set2)
     */
    public <T> Set<T> intersection(Set<T> set1, Set<T> set2)
    {
        return set1.stream().filter(set2::contains)
                .collect(Collectors.toSet());
    }

    /**
     * Returns the union of two sets
     * @param set 1
     * @param set 2
     * @return Union of set 1 and 2
     */
    public <T> Set<T> union(Set<T> set1, Set<T> set2)
    {
        return Stream.concat(set1.stream(), set2.stream())
                .collect(Collectors.toSet());
    }

    /**
     * Takes a set as input, and returns the cartesian product of the set
     * @param set
     * @param <T>
     * @return cartesian product of the set (set of tuples)
     */
    public <T> List<Tuple<T,T>> cartesianProduct(Set<T> setX, Set<T> setY)
    {
         return setX.stream().flatMap( // map each element of X to all tuples of X Y combination
            elementOfX ->
                    // produce a stream of (X, Y) tuples for each X in the form {(X,Y1), (X,Y2) ...} :
                    setY.stream()
                            .map(elementOfY -> new Tuple<T,T>(elementOfX, elementOfY))
        ).collect(Collectors.toList());
    }

    /**
     * Takes a set as input, and returns a set of tuples of all pairs (no duplicate in the form a,b and b,a --> only a,b)
     * @param set
     * @param <T>
     * @return cartesian product of the set (set of tuples)
     */
    public <T> Set<Tuple<T,T>> allPairs(Set<T> setX)
    {
        Set<Tuple<T,T>> result = new HashSet<>();
        Stack<T> elements = new Stack<>();
        elements.addAll(setX);
        while(! elements.isEmpty())
        {
            T elem = elements.pop();
            elements.stream().forEach(member -> result.add(new Tuple<>(elem, member)));
        }
        return result;
    }

}
