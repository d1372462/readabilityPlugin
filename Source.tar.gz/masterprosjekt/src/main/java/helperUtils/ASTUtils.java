package helperUtils;

import app.CurrentState;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.intellij.psi.JavaPsiFacade;

import javax.xml.stream.events.Comment;
import java.io.BufferedReader;
import java.io.StringReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ASTUtils {

    /**
     * Converts a given AST node to list of string lines
     *  WARNING: JavaParser does not use lexical preservation
     * @param ASTNode
     * @return List of string lines
     */
    public List<String> ASTNodeToLines(Node ASTNode)
    {
        return new BufferedReader(new StringReader(ASTNode.toString()))
                .lines().collect(Collectors.toList());
    }

    /**
     * Returns the number of lines an AST contains
     * (based on range from Javaparser)
     * @param ASTNode
     * @return number of lines in ast node
     */
    public int ASTNodeLineCount(Node ASTNode)
    {
        return ASTNodeToLines(ASTNode).size();
    }

    /**
     * Converts a given AST node to a StreamReader of the given source-code of the node
     * @param ASTNode
     * @return List of string lines
     */
    public BufferedReader ASTNodeToBufferedReader(Node ASTNode)
    {
        return  new BufferedReader(new StringReader(ASTNode.toString()));
    }

    /**
     * Takes a given AST node as input, and returns a list of all nodes
     * in the sub-tree of that node
     * @param astNode
     * @return List of all nodes in subtree of node
     */
    public List<Node> getAllChildNodes(Node astNode)
    {
        List<Node> nodes = new LinkedList<>();
        Queue<Node> nodeFrontier = new LinkedList<>();
        nodeFrontier.addAll(astNode.getChildNodes());
        while(!nodeFrontier.isEmpty()) // iteratively retrieve all child-nodes (avoids recursion)
        {
            Node nextNode = nodeFrontier.remove(); // dequeue front
            nodes.add(nextNode); // add front to results list
            nodeFrontier.addAll(nextNode.getChildNodes()); // enqueue child nodes for processing
        }
        return nodes;
    }

    /**
     * Returns the package of the given class, or null if non is declared
     * @param classUnit (Compilation-unit of class)
     * @return Class package name (String)
     */
    public String getPackage(CompilationUnit classUnit)
    {
        return classUnit.getPackageDeclaration().isPresent() ? classUnit.getPackageDeclaration().get().getName().asString() :
                null;
    }
}
