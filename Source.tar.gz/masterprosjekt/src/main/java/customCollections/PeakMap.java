package customCollections;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Specialized map implementation with support for min,max and peak finding
 * @param <K>
 * @param <V>
 */
public class PeakMap<K,V extends Number> extends HashMap<K,V> {
    /**
     * Finds the key mapped to the max value of all values
     *
     * @return
     */
    public K max() {
        double max = Double.MIN_VALUE;
        K maxKey = null;
        for (K key : keySet()) {
            double value = get(key).doubleValue();
            if (value >= max) {
                max = value;
                maxKey = key;
            }
        }
        return maxKey;
    }

    /**
     * Finds the key mapped to the min value of all values
     * @return
     */
    public K min() {
        double max = Double.MAX_VALUE;
        K minKey = null;
        for (K key : keySet()) {
            double value = get(key).doubleValue();
            if (value <= max) {
                max = value;
                minKey = key;
            }
        }
        return minKey;
    }

    /**
     * Returns the average of all values
     * @return average of all values
     */
    public OptionalDouble avg()
    {
        return values().stream()
                 .filter(value->  Double.isFinite(value.doubleValue()) && (!Double.isNaN(value.doubleValue())))
                .mapToDouble(value -> value.doubleValue()).average();
    }

    /**
     *  Returns a list of all keys mapped to a value that is larger than average with a minimum difference of diff
     * @param Minimum difference from average
     * @return
     */
    public Set<K> maxPeaks(double diff)
    {
        OptionalDouble optAvg = avg(); // check for isPresent, return empty list if not
        if (! optAvg.isPresent())
        {
            return new LinkedHashSet<>();
        }
        return keySet().stream()
                .filter(key -> get(key).doubleValue() >= optAvg.getAsDouble()+diff)
                .collect(Collectors.toSet());
    }

    /**
     *  Returns a list of all keys mapped to a value that is larger than average with a minimum difference of diff
     * @param Minimum difference from average
     * @return
     */
    public Set<K> minPeaks(double diff)
    {
        OptionalDouble optAvg = avg(); // check for isPresent, return empty list if not
        if (! optAvg.isPresent())
        {
            return new LinkedHashSet<>();
        }
        return keySet().stream()
                .filter(key -> get(key).doubleValue() <= optAvg.getAsDouble()+diff)
                .collect(Collectors.toSet());
    }

    /**
     *  Returns a list of all keys mapped to a value that differ from average with a minimum difference of diff
     * @param Minimum difference from average
     * @return
     */
    public Set<K> peaks(double diff)
    {
        LinkedHashSet<K> result = new LinkedHashSet<>();
        result.addAll(minPeaks(diff));
        result.addAll(maxPeaks(diff));
        return result;
    }


}
