package factories;

import interfaces.SuggestionIF;
import metricsComputers.NLPMetrics;
import metricsComputers.StructuralMetrics;
import models.Suggestion;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * Factory that produces suggestions from metrics-functions
 */
public class SuggestionFactory implements interfaces.SuggestionFactoryIF {

    private StructuralMetrics structuralMetrics;
    private NLPMetrics nlpMetrics;
    private Map<BiFunction, Suggestion> suggestionsMap;

    /**
     * Constructor for suggestionFactory. Takes an instance of structural and nlp metrics classes.
     * @param structuralMetrics
     * @param nlpMetrics
     */
    public SuggestionFactory(StructuralMetrics structuralMetrics, NLPMetrics nlpMetrics)
    {
        suggestionsMap = new HashMap<BiFunction, Suggestion>();
        this.structuralMetrics = structuralMetrics;
        this.nlpMetrics = nlpMetrics;
        populateMap();
    }

    /**
     * Inserts mappings from metrics-functions to suggestions
     */
    private void populateMap()
    {
        suggestionsMap.put(structuralMetrics.AVG_CYCLOMATIC_COMPLEXITY_FUNC,
                new Suggestion("Reduce Decision-Points","Reduce or simplify the amount of if statements and switch-cases"));
        suggestionsMap.put(structuralMetrics.MAX_NUMBER_OF_IDENTIFIERS_FUNC,
                new Suggestion("Reduce amount of identifiers used on any single line","Reduce the amount of identifiers used on a single line. Avoid using too many identifiers on a single line. (Break into multiple lines)"));
        suggestionsMap.put(structuralMetrics.MAX_IDENTIFIER_LENGTH,
                new Suggestion("Reduce length of longest identifier","Avoid unusually long identifiers."));
        suggestionsMap.put(structuralMetrics.AVG_IDENTIFIER_LENGTH_FUNC,
                new Suggestion("Ensure that identifiers are not too long and not too short","Avoid very long identifiers"));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_IDENTIFIERS_FUNC,
                new Suggestion("Reduce number of identifiers","Reduce the number of identifiers used"));
        suggestionsMap.put(structuralMetrics.MAX_OCCURRENCE_OF_IDENTIFIER,
                new Suggestion("Reduce usage of any given identifier","Avoid overly depending on a single identifier"));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_PERIODS,
                new Suggestion("Reduce depth of references (amount of periods (.))","Avoid overly deep referencing. Example: MyClass.method1().method2().method3()"));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_COMMAS,
                new Suggestion("Reduce number of parameters or comma-separated listing (number of commas)","Reduce number of parameters (number of commas). For example, encapsulation could be used instead of many parameters. Example: void createUser(UserIF user) vs void createUser(String name,String email,int phone) "));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_PARENTHESIS,
                new Suggestion("Reduce number of parenthesis","Reduce number of parenthesis. For instance caused by casting, method-class and method-declaration."));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_COMPARISONS,
                new Suggestion("Reduce number of comparisons","Reduce number of comparisons. Examples of comparisons: x == y || x && y etc..."));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_ASSIGNMENTS,
                new Suggestion("Reduce number of assignments","Reduce number of assignments. Example: int x = 2"));
        suggestionsMap.put(structuralMetrics.AVG_LINE_LENGTH_FUNC,
                new Suggestion("Avoid too short lines","Avoid too short lines. "));
        suggestionsMap.put(structuralMetrics.MAX_LINE_LENGTH_FUNC,
                new Suggestion("Avoid any one line being too long","Avoid any one line being too long"));
        suggestionsMap.put(structuralMetrics.MAX_NUMBER_OF_INDENTS_FUNC,
                new Suggestion("Reduce hierarchy depth (reduce number of indents)","A lot of indents on a single line could indicate a deep nesting hierarchy (such as loops inside loops). This should be reduced as much as possible."));
        suggestionsMap.put(structuralMetrics.AVG_NUMBER_OF_INDENTS_FUNC,
                new Suggestion("Reduce hierarchy depth (reduce number of indents)","A lot of indents on a single line could indicate a deep nesting hierarchy (such as loops inside loops). This should be reduced as much as possible."));
        suggestionsMap.put(nlpMetrics.AVG_TC,
                new Suggestion("Ensure that the class does not implement too many different concepts (keep coherent)","A class should not implement too many different concepts."));
        suggestionsMap.put(nlpMetrics.MIN_ITID,
                new Suggestion("Ensure that identifier terms/words are real dictionary words","Avoid single-character and/or nonsensical identifier names"));
        suggestionsMap.put(structuralMetrics.MAX_INSTANCES_OF_CHARS,
                new Suggestion("Avoid over-use of any single character","Ensure that comments are consistent with their method body"));
        suggestionsMap.put(nlpMetrics.MAX_CIC,
                new Suggestion("Ensure that comments are consistent with their method body","Ensure that comments are consistent with their method body"));
    }

    /**
     * Takes a metrics-function as input, and produces a suggestion
     * for the given metrics-function
     * @param metricFunc
     * @return suggestion
     */
    @Override
    public SuggestionIF produce(BiFunction metricFunc)
    {
        return suggestionsMap.get(metricFunc);
    }
}
