package factories;

import adapters.IDEAdapter;
import gui.ActionListenerAssigner;
import gui.MainToolWindowFactory;
import gui.controllers.ComposedMainGUIController;
import gui.controllers.MainToolWindowController;
import gui.controllers.PerClassTabController;
import gui.controllers.ProjectOverviewController;
import gui.factories.SuggestionComponentsFactory;
import gui.factories.SuggestionListComponentFactory;
import interfaces.*;
import metricsComputers.*;
import java.util.function.Consumer;

public class ComposedMainGUIControllerFactory {

    /**
     * Takes an exception-consumer, and an instance of the main-tool-window-factory as input, and produces an instance of
     * ComposedMainGUIController for it, with dependency-injections included
     *
     * (COMPOSITION-ROOT FOR GUI CONTROLLERS)
     *
     * NOTE: Should be replaced with DI framework such as Google Guice
     * @param project
     * @param mainToolWindowFactory
     */
    public ComposedMainGUIController provide(MainToolWindowFactory mainToolWindowFactory, Consumer<Exception> exceptionConsumer)
    {
        System.out.println("---"+mainToolWindowFactory);
        // init dependencies:
         final NLPMetrics nlpMetrics = new NLPMetrics();
         final StructuralMetrics structuralMetrics = new StructuralMetrics();
         final MetricsAggregatorIF metricsAggregator = new MetricsAggregator(structuralMetrics,nlpMetrics);
         final ModelComputerIF modelComputer = new ModelComputer(structuralMetrics,nlpMetrics);
         final SuggestionFactoryIF suggestionFactory = new SuggestionFactory(structuralMetrics,nlpMetrics);
         final SuggestionComponentsFactoryIF suggestionComponentsFactory = new SuggestionComponentsFactory();
         final MetricsWeighterIF metricsWeighter = new MetricsWeighter(structuralMetrics,nlpMetrics);
         final ActionListenerAssignerIF actionListenerAssigner = new ActionListenerAssigner();
         final SuggestionListComponentFactory suggestionListComponentFactory = new SuggestionListComponentFactory(
              structuralMetrics,nlpMetrics,suggestionFactory,suggestionComponentsFactory, actionListenerAssigner
         );
         final ProjectMetricsComputer projectMetricsComputer = new ProjectMetricsComputer(
                 exceptionConsumer,
                 metricsAggregator,
                 metricsWeighter
         );
        final PerClassTabController tabsController = new PerClassTabController( // tabs-controller
                projectMetricsComputer,
                metricsAggregator,
                suggestionListComponentFactory
        );
        final IDEAdapterIF ideAdapter = new IDEAdapter();
        final MainToolWindowControllerIF mainToolWindowController = new MainToolWindowController();
        final PerClassTabControllerIF perClassTabController = new PerClassTabController(
                projectMetricsComputer,metricsAggregator,suggestionListComponentFactory
        );
        final ProjectOverviewController projectOverviewController = new ProjectOverviewController(
                ideAdapter,actionListenerAssigner, mainToolWindowController, perClassTabController
        );
        // create instance (with dependancy-injections):
        return new ComposedMainGUIController(
                ideAdapter,
                projectMetricsComputer,
                modelComputer,
                suggestionListComponentFactory,
                tabsController,
                projectOverviewController
        );
    }
}
