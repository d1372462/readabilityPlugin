package components;

import app.CurrentState;
import com.intellij.execution.ui.ConsoleView;
import com.intellij.notification.Notification;
import com.intellij.notification.NotificationType;
import com.intellij.notification.Notifications;
import com.intellij.openapi.components.ProjectComponent;
import factories.ComposedMainGUIControllerFactory;
import gui.controllers.ComposedMainGUIController;
import org.jetbrains.annotations.NotNull;

public class OnProjectLoadComponent implements ProjectComponent {
    public OnProjectLoadComponent () {
        Notifications.Bus.notify(new Notification(ConsoleView.CONSOLE_CONTENT_ID, "ALOKR-", "constructor", NotificationType.INFORMATION));
    }

    @Override
    public void initComponent() {
        // TODO: insert component initialization logic here
        Notifications.Bus.notify(new Notification(ConsoleView.CONSOLE_CONTENT_ID, "ALOKR-", "init component", NotificationType.INFORMATION));
    }

    @Override
    public void disposeComponent() {
        // TODO: insert component disposal logic here
        Notifications.Bus.notify(new Notification(ConsoleView.CONSOLE_CONTENT_ID, "ALOKR-", "dispose component", NotificationType.INFORMATION));
    }

    @Override
    @NotNull
    public String getComponentName() {
        Notifications.Bus.notify(new Notification(ConsoleView.CONSOLE_CONTENT_ID, "ALOKR-", "get component name", NotificationType.INFORMATION));
        return "filelistener";
    }

    @Override
    public void projectOpened() {
        // wait 8 secs to update stats:
        /*
        new java.util.Timer().schedule(
                new java.util.TimerTask() {
                    @Override
                    public void run() {
                        new ComposedMainGUIControllerFactory().provide(
                                CurrentState.getInstance().getMainToolWindow(),
                                exception -> System.err.println(exception.getMessage())
                        ).updateAllStats(CurrentState.getInstance().getCurrentProject());
                    }
                },
                8000
        );
        */

    }

    @Override
    public void projectClosed() {
        Notifications.Bus.notify(new Notification(ConsoleView.CONSOLE_CONTENT_ID, "ALOKR-", "project closed", NotificationType.INFORMATION));
        // called when project is being closed
    }
}