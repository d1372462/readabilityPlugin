package components;

/**
 * Contains logic to be called for updating the plugin stats
 */
public class UpdateEvent {

    public void performUpdate()
    {

    }
}
