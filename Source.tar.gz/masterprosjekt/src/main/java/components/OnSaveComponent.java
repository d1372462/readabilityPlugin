package components;

import actions.RefreshAction;
import app.CurrentState;
import com.intellij.AppTopics;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ApplicationComponent;
import com.intellij.openapi.editor.Document;
import com.intellij.openapi.fileEditor.FileDocumentManagerAdapter;
import com.intellij.util.messages.MessageBus;
import com.intellij.util.messages.MessageBusConnection;
import factories.ComposedMainGUIControllerFactory;
import gui.controllers.ComposedMainGUIController;
import org.jetbrains.annotations.NotNull;

public class OnSaveComponent implements ApplicationComponent {

    @NotNull
    public String getComponentName() {
        return "Plugin On-Save Component";
    }

    public void initComponent() {
       final ComposedMainGUIController composedMainGUIController = new ComposedMainGUIControllerFactory().provide(
                CurrentState.getInstance().getMainToolWindow(),
                exception -> exception.printStackTrace());

       // set refresh MainGuiController reference:
        RefreshAction.setMainGUIController(composedMainGUIController);
        // set up subscriber action-listener:
        MessageBus bus = ApplicationManager.getApplication().getMessageBus();
        MessageBusConnection connection = bus.connect();
        connection.subscribe(AppTopics.FILE_DOCUMENT_SYNC,
                new FileDocumentManagerAdapter() {
                    @Override
                    public void beforeDocumentSaving(Document document) {
                        composedMainGUIController.updateAllStats(CurrentState.getInstance().getCurrentProject());
                    }


                });
    }

    public void disposeComponent() {

    }
}