package app;

import com.intellij.openapi.project.Project;
import gui.MainToolWindowFactory;
import models.ClassState;
import models.setModels.MetricsSnapshot;
import models.setModels.Tuple;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Singleton Holds current open project for global access
 */
public class CurrentState {

    private static CurrentState instance;

    private Project currentProject;

    private MainToolWindowFactory mainToolWindow;

    private Map<String, Tuple<ClassState,MetricsSnapshot>> currentMetricsResults; // class-name --> tuple

    private CurrentState()
    {
        currentMetricsResults = Collections.synchronizedMap(new HashMap<>());
    }

    public static synchronized CurrentState getInstance()
    {
        if (instance == null)
        {
            instance = new CurrentState();
        }
        return instance;
    }

    // SETTERS & GETTERS:

    public Project getCurrentProject() {
        return currentProject;
    }

    public MainToolWindowFactory getMainToolWindow() {
        return mainToolWindow;
    }

    public Map<String, Tuple<ClassState, MetricsSnapshot>> getCurrentMetricsResults() {
        return currentMetricsResults;
    }

    public void setCurrentMetricsResults(Map<String, Tuple<ClassState, MetricsSnapshot>> currentMetricsResults) {
        this.currentMetricsResults = currentMetricsResults;
    }

    public void setCurrentProject(Project currentProject) {
        this.currentProject = currentProject;
    }

    public void setMainToolWindow(MainToolWindowFactory mainToolWindow) {
        this.mainToolWindow = mainToolWindow;
    }
}
