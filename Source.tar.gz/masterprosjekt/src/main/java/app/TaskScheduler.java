package app;

import interfaces.TaskIF;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * Class to enable the repeated scheduling of tasks
 */
public class TaskScheduler {
    private Queue<TaskIF> tasks = new LinkedList<>();
    private Timer timer;
    private int interval = 2000; // default 5 secs

    public void addTask(TaskIF task)
    {
        tasks.add(task);
    }

    /**
     * Starts the task-schedule
     */
    public void start()
    {
       timer = new Timer();
       timer.schedule(new TimerTask() {
        @Override
        public void run() {
            doTasks();
        }
    }, 0, interval);
    }
    /**
     * Stops the task-schedule
     */
    public void stop()
    {
        timer.cancel();
    }

    /**
     * Calls doTask on all tasks in queue (in order)
     * (synchronized to avoid call-overlap in case execution time > interval)
     */
    private synchronized void doTasks()
    {
        tasks.stream().forEach(task -> task.doTask());
    }

    // GETTERS:
    public Queue<TaskIF> getTasks() {
        return tasks;
    }

    public int getInterval() {
        return interval;
    }

    // SETTERS:
    public void setTasks(Queue<TaskIF> tasks) {
        this.tasks = tasks;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }
}
