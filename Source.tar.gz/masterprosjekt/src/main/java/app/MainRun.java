package app;

import com.intellij.openapi.project.Project;
import factories.ComposedMainGUIControllerFactory;
import gui.MainToolWindowFactory;

public class MainRun {

    /**
     * Called when the plugin is started. Initiates initial startup procedures
     * @param mainToolWindowFactory
     */
    public void started(MainToolWindowFactory mainToolWindowFactory, Project currentProject)
    {
        // set current state:
        CurrentState.getInstance().setCurrentProject(currentProject);
        CurrentState.getInstance().setMainToolWindow(mainToolWindowFactory);
    }
}
