package singletons;

import exceptions.AlreadyInitializedException;
import interfaces.StringSetProvider;
import java.io.FileNotFoundException;
import java.util.Set;

/**
 * Singleton to hold a loaded english dictionary to use during the entire run-time of
 * the application. The dictionary is expensive to load, thus a singleton is used to ensure that the
 * words are only loaded once per run-time.
 */
public class DictionaryService {

    private Set<String> words;
    private static DictionaryService instance;

    private DictionaryService()
    {

    }

    public static DictionaryService getInstance()
    {
        if(instance==null)
        {
            instance = new DictionaryService();
        }
        return instance;
    }

    /**
     * Receives a dictionary xml file path as param, and loads the given
     * dictionary file in memory.  Can only be called once per instance.  Returns false if already initialized
     * @param dictionaryFilePath
     */
    public void initialize( StringSetProvider stringSetProvider) throws FileNotFoundException {
        if (! words.isEmpty()) // check if already initialized
        {
            throw new AlreadyInitializedException();
        }
        words = stringSetProvider.extractWords(); // use provider to extract words from file
    }

    /**
     * Getter for word-set
     * @return set of words in currently loaded dictionary
     */
    public Set<String> getWords()
    {
        return words;
    }
}
