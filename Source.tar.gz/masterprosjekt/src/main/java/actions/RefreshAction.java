package actions;
import app.CurrentState;
import com.intellij.openapi.actionSystem.*;
import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.project.Project;
import gui.controllers.ComposedMainGUIController;

/**
 * Action for doing a complete re-analyze of the current project
 * (flushes class-hashes and does a complete analysis of project)
 */
public class RefreshAction extends AnAction {
    private static ComposedMainGUIController mainGUIController;
    public RefreshAction() {
        super("Refresh Analysis");
    }

    /**
     * Defines visibility
     * (conditions that must be true for option to be visible in menu)
     * @param e
     */
    @Override
    public void update(AnActionEvent e) {
        // check project and gui controller available:
        e.getPresentation().setVisible(CurrentState.getInstance().getCurrentProject() != null
                && mainGUIController != null);
    }

    @Override
    public void actionPerformed(AnActionEvent event) {
        System.out.println("Performs full analysis of project");
        CurrentState.getInstance().getCurrentMetricsResults().clear(); // clear class-hash cache
        mainGUIController.updateAllStats(CurrentState.getInstance().getCurrentProject());
    }

    public static void setMainGUIController(ComposedMainGUIController mainGUIController) {
        RefreshAction.mainGUIController = mainGUIController;
    }
}