package parsing;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;

import java.io.FileInputStream;

/**
 * Wrapper class for building an abstract syntax tree from code
 */
public class ASTBuilder {
    /**
     * Builds an abstract syntax tree from given source-code
     * @return
     */
    public CompilationUnit buildAST(String code) {
        // build tree:
        return JavaParser.parse(code);
    }

    /**
     * Builds an abstract syntax tree from given source-code
     * @return
     */
    public CompilationUnit buildAST(FileInputStream code) {
        // build tree:
        return JavaParser.parse(code);
    }
}
