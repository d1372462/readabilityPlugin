package outputCatchers;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import interfaces.ExceptionCatcherIF;
import interfaces.OutputCatcherIF;
import models.Term;
import models.TextNode;
import models.setModels.MetricsSnapshot;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.LinkedList;
import java.util.List;

/**
 * Accepts a MetricsSnapshot container as input, and stores it in JSON format
 */
public class JsonOutputCatcherIF implements OutputCatcherIF {
private String outFilePath;
private ExceptionCatcherIF exceptionCatcher;

    /**
     * Stores the received MetricsSnapshot as JSON output to file
     * @param outFilePath - File path for output
     * @param exceptionCatcher - catcher to receive potential exceptions during processing of input
     */
    public JsonOutputCatcherIF(String outFilePath, ExceptionCatcherIF exceptionCatcher)
    {
        this.outFilePath = outFilePath;
        this.exceptionCatcher=exceptionCatcher;
    }

    /**
     * Accept metricsmodel and serialize and write to json
     * @param snapshot object
     */
    @Override
    public void accept(MetricsSnapshot snapshot) {
        Writer writer = null;
        try {
            writer = new FileWriter(outFilePath);
        } catch (IOException e) {
            exceptionCatcher.accept(e); // pass exception to exception-catcher
        }
        Gson gson = new GsonBuilder().create();
        gson.toJson(snapshot, writer);
    }
}
