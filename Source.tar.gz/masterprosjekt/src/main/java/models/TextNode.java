package models;

import com.github.javaparser.Range;

import java.util.Optional;

public abstract class TextNode {
    private String name;
    private Optional<Range> range;
    public TextNode(String name)
    {
        this.name=name;
    }
    public TextNode(String name, Optional<Range> range)
    {
        this(name);
        this.setRange(range);
    }
    public TextNode(){

    }

    @Override
    public boolean equals(Object obj)
    {
        return obj instanceof TextNode && this.name.equals(((TextNode) obj).getName());
    }

    @Override
    public int hashCode()
    {
        return name.hashCode();
    }

    // GETTERS AND SETTERS:
    public String getName()
    {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public Optional<Range> getRange() {
        return range;
    }

    public void setRange(Optional<Range> range) {
        this.range = range;
    }

    @Override
    public String toString()
    {
        return name;
    }
}