package models;

/**
 * Holds the name of a given class, and a hash of the source-code of the given class
 */
public class ClassState {
    private String name;
    private String hash;

    public ClassState(String name, String hash)
    {
        this.name=name;
        this.hash = hash;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }
}
