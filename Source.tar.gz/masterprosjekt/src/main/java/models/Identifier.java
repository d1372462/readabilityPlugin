package models;

import com.github.javaparser.Range;

import java.util.Objects;
import java.util.Optional;

/**
 * Wrapper class for a given source-code identifier
 */
public class Identifier extends TextNode {

    public Identifier(String identifier, Optional<Range> range)
    {
        super(identifier,range);
    }
    public Identifier(String identifier)
    {
        super(identifier);
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(this.getName(),this.getRange());
    }

    @Override
    public boolean equals(Object obj)
    {
        return hashCode()==obj.hashCode();
    }

}
