package models;

import java.util.LinkedList;
import java.util.List;

/**
 * Represents a sentence of multiple terms
 */
public class Sentence {
private List<Term> terms;
    public Sentence(List<Term> terms)
    {
        this();
        this.terms.addAll(terms);
    }

    public Sentence()
    {
        this.terms=new LinkedList<Term>();
    }



}
