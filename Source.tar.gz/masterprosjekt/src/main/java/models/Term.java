package models;

import com.github.javaparser.Range;
import com.github.javaparser.TokenRange;

import java.util.Optional;

/**
 * Represents a single term / word of an identifier
 */
public class Term extends TextNode{

    public Term(String term, Optional<Range> range)
    {
        super(term,range);
    }
    public Term(String term)
    {
        super(term);
    }


}
