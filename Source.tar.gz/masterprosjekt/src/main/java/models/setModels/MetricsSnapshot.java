package models.setModels;

import interfaces.MetricsSnapshotIF;
import interfaces.MetricsWeighterIF;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * Represents a metrics-snapshot
 */
public class MetricsSnapshot implements MetricsSnapshotIF {
    private Date snapshotTime;
    private Map<BiFunction,Double> metricsValues;
    private Map<BiFunction,Double> weightedMetricsValues;

    public MetricsSnapshot()
    {
        metricsValues = new HashMap<>();
        weightedMetricsValues = new HashMap<>();
    }

    /**
     * Calculates the average of metricsValues
     * @return metrics average (double)
     */
    public double calcAverage()
    {
        OptionalDouble result = metricsValues.values().stream()
                .mapToDouble(val -> val)
                .filter(value->  Double.isFinite(value) && (!Double.isNaN(value)))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    }

    /**
     * Calculates the average of weightedMetricsValues
     * @return metrics average (double)
     */
    public double calcWeightedAverage(MetricsWeighterIF weighter)
    {
        OptionalDouble result = weightedMetricsValues.values().stream()
                .mapToDouble(val -> val)
                .filter(value->  Double.isFinite(value) && (!Double.isNaN(value)))
                .average();
        return result.isPresent() ? result.getAsDouble() : 0;
    }

    // GETTERS:

    public Date getSnapshotTime() {
        return snapshotTime;
    }

    public Map<BiFunction, Double> getMetricsValues() {
        return metricsValues;
    }

    public Map<BiFunction, Double> getWeightedMetricsValues() {
        return weightedMetricsValues;
    }

    // SETTERS:

    public void setSnapshotTime(Date snapshotTime) {
        this.snapshotTime = snapshotTime;
    }

    public void setMetricsValues(Map<BiFunction, Double> metricsValues) {
        this.metricsValues = metricsValues;
    }

    public void setWeightedMetricsValues(Map<BiFunction, Double> weightedMetricsValues) {
        this.weightedMetricsValues = weightedMetricsValues;
    }

}