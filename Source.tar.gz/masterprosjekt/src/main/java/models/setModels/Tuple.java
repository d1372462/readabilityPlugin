package models.setModels;

import java.util.Objects;

public class Tuple <X,Y>{
    private X x;
    private Y y;

    public <T,U>Tuple(X x, Y y)
    {
        this.x = x;
        this.y = y;
    }

    // GETTERS AND SETTERS:

    public X getX() {
        return x;
    }

    public void setX(X x) {
        this.x = x;
    }

    public Y getY() {
        return y;
    }

    public void setY(Y y) {
        this.y = y;
    }

    /**
     * Checks equality to given tuple
     * @param tuple
     * @return
     */
    @Override
    public boolean equals(Object tuple)
    {
        return tuple instanceof Tuple && // check that given object is a tuple
                ((Tuple)tuple).getX().equals(x) && ((Tuple)tuple).getY().equals(y); // check equality between members
    }

    @Override
    public int hashCode()
    {
        return Objects.hash(getX(),getY()); // generate hash combining the hash of X and Y elements
    }

    @Override
    public String toString()
    {
        return "("+x+", "+y+")";
    }

    /**
     * Returns a new reversed tuple of this tuple
     * @return Reversed tuple
     */
    public Tuple<Y,X> reversed()
    {
        return new Tuple<>(y,x);
    }
}
