package adapters;

import com.github.javaparser.ast.CompilationUnit;
import com.intellij.ide.highlighter.JavaFileType;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.psi.JavaPsiFacade;
import com.intellij.psi.PsiClass;
import com.intellij.psi.PsiMethod;
import com.intellij.psi.PsiPackage;
import com.intellij.psi.search.FileTypeIndex;
import com.intellij.psi.search.GlobalSearchScope;
import com.intellij.util.indexing.FileBasedIndex;
import helperUtils.ASTUtils;
import parsing.ASTBuilder;

import javax.xml.bind.annotation.XmlElementDecl;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Adapter containing methods for extracting data from the current project on which the
 * plugin operates.
 */
public class IDEAdapter implements interfaces.IDEAdapterIF {
    private ASTBuilder astBuilder;
    private ASTUtils astUtils;

    public IDEAdapter()
    {
        astBuilder = new ASTBuilder();
        astUtils = new ASTUtils();
    }
    /**
     * Returns a list of virtual files of all classes in the current project
     * @param project
     * @return List of classes (virtual files)
     */
    @Override
    public List<VirtualFile> getClassesInProject(Project project)
    {
        return new ArrayList<>(FileBasedIndex.getInstance().getContainingFiles(
                FileTypeIndex.NAME,
                JavaFileType.INSTANCE,
                GlobalSearchScope.projectScope(project)));
    }
        /**
         * Returns a list of virtual files of all classes in the current project
         * @param project
         * @return List of classes (virtual files)
         */
        @Override
        public List<PsiClass> getClassesInProject_Psi(Project project)
        {
            // build AST of each class:
            List<CompilationUnit> ASTs = getClassesInProject(project).stream().parallel()
                    .map(projClass -> astBuilder.buildAST(virtualFileToString(projClass)))
                    .collect(Collectors.toList());
            List<PsiClass> classList = new LinkedList<>();
            // extract all from default-package:
             classList.addAll(
                     ASTs.stream()
                            .filter(classAST -> ! classAST.getPackageDeclaration().isPresent())
                            .filter(classAST->classAST.getTypes().size() >0)
                            .map(classAST -> JavaPsiFacade.getInstance(project).findClass(classAST.getTypes().get(0).getName().asString(), GlobalSearchScope.allScope(project)))
                            .collect(Collectors.toList())
            );
             // add rest:
            classList.addAll( getPackagesInProject(project).stream()
                    .flatMap(pack -> Arrays.stream(pack.getClasses()))
                    .collect(Collectors.toList()));
            return classList;
        }

    /**
     * Finds all methods in given project and returns a map of all classes with their respective methods
     * @param project
     * @return map in the form class -> list of methods in class
     */
    @Override
    public Map<PsiClass,List<PsiMethod>> getMethodsInProject_Psi(Project project)
        {
            Map<PsiClass,List<PsiMethod>> result = new HashMap<>();
            getClassesInProject_Psi(project).stream().forEach(
                    psiClass -> result.put(psiClass, Arrays.stream(psiClass.getAllMethods()).collect(Collectors.toList()))
            );
            return result;
        }

    /**
     * Returns a list of packages in the current project (TO BE IMPROVED: ONLY INCLUDE PACKAGES FROM THE MAIN MODULE)
     * @param project
     * @return List of classes (virtual files)
     */
    @Override
    public Set<PsiPackage> getPackagesInProject(Project project)
    {
        Set<PsiPackage> packages = new HashSet<>(); // set to ensure uniqueness
         getClassesInProject(project).stream()
                .map(projClass ->
                        astUtils.getPackage(
                                astBuilder.buildAST(virtualFileToString(projClass))
                        ))
                .filter(packageName -> packageName != null)
                 .distinct()
                 .map(packageName -> JavaPsiFacade.getInstance(project).findPackage(packageName))
                 .distinct()
                .forEach(pack -> {
                            packages.add(pack); // add main package
                            packages.addAll(Arrays.asList(pack.getSubPackages())); // add sub-package
                        });
        return packages;
    }

    @Override
    public String virtualFileToString(VirtualFile file)
    {
        try {
            return new String(file.contentsToByteArray());
        } catch (IOException e) {
            return null;
        }
    }

    /**
     * Get current open virtual-file from project
     * @param project
     * @return
     */
    @Override
    public VirtualFile getCurrentOpenFile(Project project)
    {
        FileEditorManager manager = FileEditorManager.getInstance(project);
        VirtualFile files[] = manager.getSelectedFiles();
        if (files.length<1)
        {
            return null;
        }
        return files[0];
    }
}
