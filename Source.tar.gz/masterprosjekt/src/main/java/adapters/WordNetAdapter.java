package adapters;

import constants.FilePaths;
import edu.mit.jwi.Dictionary;
import edu.mit.jwi.IDictionary;
import edu.mit.jwi.item.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Adapter-class for interacting with wordnet library.
 */
public abstract class WordNetAdapter {

    private static IDictionary dictionary;

    /**
     * Retrns an instance of wordnet dictionary.  Singleton-like to force re-use of object-instance
     * that is costly to produce.
     * @return
     */
    public static IDictionary getDictionary()
    {
        if (dictionary == null)
        {
            loadDictionary();
        }
        return dictionary;
    }

    /**
     * Receives a string word and a POS category, and fetches the corresponding WordNet word
     * @param word
     * @param pos
     * @return IWord WordNet Word
     */
    public static synchronized IWord getWord(String word, POS pos)
    {
        IIndexWord wordIndex = getDictionary().getIndexWord(word, pos); // get word index
        return wordIndex == null ? null : // if word index is null, return null
                getDictionary().getWord(wordIndex.getWordIDs().get(0)); // else return word from first index
    }

    /**
     * Receives a string word as input, and searches for the pos for that word, and returns the word
     * with the correct pos once found.  Proxy for calling getWord when POS category is not known
     * @param String word to get
     * @return IWord for the corresponding string
     */
    public static synchronized IWord getWord(String word)
    {
        if (word.trim().length()<1)
        {
            return null;
        }
        for (POS pos : POS.values())
        {
                        IWord iWord = getWord(word, pos);
                        if (iWord != null)
                        {
                            return iWord;
                        }
        }
         return null;
    }

    /**
     * Receives a string word as input, and cehcks if the given word
     * exists in the dictionary under any pos category
     * @param word
     * @return
     */
    public static synchronized boolean isWord(String word)
    {
            return word.trim().length() > 0 && getWord(word) != null;
    }

    /**
     * Measures the depth of the given word in the WordNet hypernym-tree
     * @param word
     * @return
     */
    public static synchronized int getWordHypernymDepth(IWord word)
    {
        // check word has hypernym:
        if (getHyperNyms(word).size() < 1)
        {
            return 0;
        }
        // get hypernyms of word:
        IWord hyperNym = word;
        int depth = 0;
        while(getHyperNyms(word).size() >0) // dontinue while current word has hypernyms
        {
            word =  getHyperNyms(word).get(0); // select first hypernym from word
            depth++; // increment depth
        }
        return depth;
    }

    public static synchronized List<IWord> getHyperNyms(IWord word)
    {
       return word.getSynset().getRelatedSynsets(Pointer.HYPERNYM).stream().parallel()
               .flatMap(
               synsetId -> getDictionary().getSynset(synsetId).getWords().stream())
               .collect(Collectors.toList());
    }

    private static void loadDictionary()
    {
        try {
            URL fileUrl = new URL("file",null,FilePaths.WORDNET_DICTIONARY);
            dictionary = new Dictionary(fileUrl);
            dictionary.open();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
