package extractors;

import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.nodeTypes.NodeWithBody;
import com.github.javaparser.ast.stmt.*;
import models.Identifier;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Responsible for extracting constructs from a given AST Node
 */
public class ASTExtractor {
    /**
     * Extracts all identifiers from given node
     * @param ASTNode
     * @return Set of identifiers
     */
    public List<Identifier> extractIdentifiers(Node ASTNode)
    {
        return ASTNode.findAll(SimpleName.class).stream()
                .map(var -> new Identifier(var.getIdentifier(), var.getRange()))
                .collect(Collectors.toList());
    }

    /**
     * Extracts all identifiers from multiple ast nodes
     * @param ASTNode
     * @return Set of identifiers
     */
    public List<Identifier> extractIdentifiers(Node... astNodes )
    {
        List<Identifier> result = new LinkedList<>();
        for(Node node : astNodes)
        {
            result.addAll(extractIdentifiers(node));
        }
        return result;
    }

    /**
     * Extracts all identifiers from multiple ast nodes
     * @param ASTNode
     * @return Set of identifiers
     */
    public List<Identifier> extractIdentifiers(List<Node> astNodes )
    {
        List<Identifier> result = new LinkedList<>();
        for(Node node : astNodes)
        {
            result.addAll(extractIdentifiers(node));
        }
        return result;
    }

    /**
     * Extracts all control-statements from a given ASTNode
     * @param ASTNode
     * @return Set of control-statements
     */
    public Set<Node> extractControlStatements(Node ASTNode)
    {
        Set<Node> result = new HashSet<>();
         Stream.of(
                ASTNode.findAll(IfStmt.class).stream(), // find all if statements
                ASTNode.findAll(SwitchStmt.class).stream(), // find all switch statements
                ASTNode.findAll(ForeachStmt.class).stream(), // find all for-each statements
                ASTNode.findAll(ForStmt.class).stream(), // find all for-statements
                ASTNode.findAll(WhileStmt.class).stream(), // find all while statements
                ASTNode.findAll(DoStmt.class).stream() // find all do-while statements
        ).reduce(Stream::concat).get()
                .forEach(
                        node ->{
                            if (node instanceof NodeWithBody)
                            {
                                result.add(((NodeWithBody)node).getBody().clone());
                            }
                            if (node instanceof IfStmt)
                            {
                                IfStmt n = ((IfStmt)node);
                                result.add(n.getThenStmt());
                                if (n.hasElseBlock())
                                {
                                    result.add(n.getElseStmt().get().clone());
                                }
                            }
                        }
                );
         return result;
    }


    /**
     * Extracts all control-statements from a given ASTNode
     * @param ASTNode
     * @return Set of control-statements
     */
    public Set<Node> extractControlStatements_WithParent(Node ASTNode)
    {
        return Stream.of(
                ASTNode.findAll(IfStmt.class).stream(), // find all if statements
                ASTNode.findAll(SwitchStmt.class).stream(), // find all switch statements
                ASTNode.findAll(ForeachStmt.class).stream(), // find all for-each statements
                ASTNode.findAll(ForStmt.class).stream(), // find all for-statements
                ASTNode.findAll(WhileStmt.class).stream(), // find all while statements
                ASTNode.findAll(DoStmt.class).stream() // find all do-while statements
        ).reduce(Stream::concat).get()
                .collect(Collectors.toSet());
    }

    /**
     * Returns a set of all comments from an AST Node
     * @param ASTNode
     * @return Set of comment-nodes from ast node
     */
    public List<Node> extractComments(Node ASTNode)
    {
        return ASTNode.getAllContainedComments().stream().collect(Collectors.toList());
    }

    /**
     * Takes a list of ast-nodes as input, and strips control-statements from each node
     * @param astNodes
     * @return List of nodes without their control statements
     */
    public Set<Node> stripControlStatements(Set<Node> astNodes)
    {
        Set<Node> nodes = astNodes.stream().map(node -> node.clone()) // clone to avoid mutating AST
                .collect(Collectors.toSet());
        nodes.stream().parallel().forEach(
            node -> extractControlStatements_WithParent(node).stream().forEach(controlStm -> controlStm.remove() ) // remove each control-statement from each node
        );
        return nodes;
    }

    /**
     * Strips all comments from a given AST node
     * @param astNode
     * @return ASTNode with comments removed
     */
    public Node stripComments(Node astNode)
    {
        Node nodeClone = astNode.clone();
        extractComments(astNode).stream().forEach(comment -> comment.remove());
        return nodeClone;
    }


}
