package dataProviders;
import interfaces.StringSetProvider;
import org.w3c.dom.NodeList;
import parsing.XPathParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Set;

/**
 * Provides TrainingSets for keyword matcher & sentiment analyzer
 */
public class DictionaryWordProvider implements StringSetProvider {
    private XPathParser xPathParser;
    private String path;

    public DictionaryWordProvider(String path) throws FileNotFoundException {
        if (! new File(path).exists()) // check dictionary-file exists
        {
            throw new FileNotFoundException("Dictionary XML file not found");
        }
        this.xPathParser=new XPathParser();
        this.path=path;
    }

    /**
     * Provides words from a dictionary xml file
     * @return Training Set
     */
    public Set<String> extractWords()
    {
        Set<String> terms = new HashSet<String>();
        // do xpath query to fetch positive examples:
        NodeList xpathResult = xPathParser.query("//word/text", path);
        for(int wordIndex=0; wordIndex < xpathResult.getLength(); wordIndex++)
        {
            terms.add(xpathResult.item(wordIndex).getTextContent());
        }
        return terms;
    }

}
